"""
social.py - levels, achievements and Friends for Pips.

* Levels / XP / streak / achievements are computed locally from the pomodoro
  history (data/productivity.db) and the pet state - they work offline.
* Friends (opt-in, off by default) syncs a tiny public profile to the Pips
  Friends server (Cloudflare Worker + D1) so friends and teams can see each
  other's level, streak and pomodoro counts. Shared: display name, pet animal +
  colour, level, XP, streak, today's / this week's pomodoros and focus minutes,
  achievements, pet mood. Never: app names, window titles, scores, files.

v2.6 adds public / private profiles (photo, bio, info), online status,
friend requests for private profiles, relationship labels and a global
leaderboard of everyone using Pips.

v2 adds chat (friends + groups), private groups ("circles") with invites,
affinity (friendship level that grows with every interaction) and pet
interactions: wave, pet, snack, high five and pet visits (the friend's pet
walks onto your desktop for a moment).

Account (id + secret + friend code) lives in data/social.json on this PC.
The window lives in social_ui.py. All user-facing text comes from i18n.py.
"""

from __future__ import annotations

import base64
import json
import logging
import math
import os
import queue
import random

try:
    import pet_shop
except ImportError:  # pragma: no cover
    pet_shop = None
import sqlite3
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

try:
    from i18n import t
except ImportError:  # pragma: no cover
    def t(key, lang=None, **kwargs):
        return key.format(**kwargs) if kwargs else key

logger = logging.getLogger("social")

API_URL = "https://pips-friends.juwenmondial.workers.dev"
SYNC_EVERY_S = 10 * 60
BOARD_EVERY_S = 15 * 60
ACH_CHECK_EVERY_S = 5 * 60
FRIEND_NEWS_GAP_S = 30 * 60
# The app's creator. The "owner" role itself is granted only on the server (by friend code),
# so nobody else can claim it from the app.
OWNER_NAME = "Juwen Lie"
OWNER_EMAIL = "Juwen_Lie@pegatroncorp.com"
OWNER_LEVEL = 99
OWNER_XP = 999999
PREMIUM_FOREVER = 4102444800        # server value for "Premium forever"
STAFF_ROLES = ("owner", "mod")

INBOX_EVERY_S = 45
IDLE_AWAY_S = 10 * 60          # idle this long -> "away" (auto status)
INBOX_FAST_S = 5          # while a chat is open
MAX_ROOM_HISTORY = 150

# affinity (friendship) levels: (points needed, i18n key)
AFFINITY_LEVELS = [(0, "aff_acq"), (20, "aff_buddy"), (60, "aff_good"), (150, "aff_close"),
                   (300, "aff_best"), (600, "aff_soul")]
INTERACTIONS = ("wave", "pet", "snack", "highfive", "visit")
INTERACTION_SYMBOL = {"wave": "\u270b", "pet": "\u2665", "snack": "\u2615", "highfive": "\u2605",
                      "visit": "\u2302", "cheer": "\u266b"}


def affinity_level(points: int):
    """-> (level index 0.., i18n key, points of this level, points of next level or None)."""
    points = max(0, int(points or 0))
    index = 0
    for i, (need, _key) in enumerate(AFFINITY_LEVELS):
        if points >= need:
            index = i
    nxt = AFFINITY_LEVELS[index + 1][0] if index + 1 < len(AFFINITY_LEVELS) else None
    return index, AFFINITY_LEVELS[index][1], AFFINITY_LEVELS[index][0], nxt

# (id, symbol, condition) - names/descriptions are i18n keys "ach_<id>"
ACHIEVEMENTS = [
    ("first_pom", "\u2605", lambda s: s["total_poms"] >= 1),
    ("poms_10", "\u2726", lambda s: s["total_poms"] >= 10),
    ("poms_50", "\u2742", lambda s: s["total_poms"] >= 50),
    ("poms_100", "\u2654", lambda s: s["total_poms"] >= 100),
    ("poms_250", "\u265b", lambda s: s["total_poms"] >= 250),
    ("day_4", "\u2618", lambda s: s["best_day_poms"] >= 4),
    ("day_8", "\u2600", lambda s: s["best_day_poms"] >= 8),
    ("streak_3", "\u2668", lambda s: s["best_streak"] >= 3),
    ("streak_7", "\u2604", lambda s: s["best_streak"] >= 7),
    ("streak_14", "\u269d", lambda s: s["best_streak"] >= 14),
    ("early_bird", "\u263c", lambda s: s["early_bird"]),
    ("night_owl", "\u263e", lambda s: s["night_owl"]),
    ("weekend", "\u2740", lambda s: s["weekend"]),
    ("level_5", "\u2691", lambda s: s["level"] >= 5),
    ("level_10", "\u269c", lambda s: s["level"] >= 10),
    ("pet_lover", "\u2665", lambda s: s["pets_total"] >= 50),
    ("tickler", "\u266a", lambda s: s["tickles_total"] >= 100),
    ("chef", "\u2615", lambda s: s["snacks_total"] >= 20),
    ("friend_1", "\u263a", lambda s: s["friends"] >= 1),
    ("team_1", "\u2691", lambda s: s["groups"] >= 1),
    ("close_friend", "\u2766", lambda s: s.get("max_affinity", 0) >= 150),
    ("visitor", "\u2302", lambda s: s.get("visits_sent", 0) >= 1),
]
ACH_IDS = [a[0] for a in ACHIEVEMENTS]
ACH_SYMBOL = {a[0]: a[1] for a in ACHIEVEMENTS}


# =============================================================================
# Levels & stats (offline)
# =============================================================================

def xp_for_level(level: int) -> int:
    """Total XP needed to reach `level` (level 1 = 0 XP, 2 = 100, 3 = 300, 4 = 600...)."""
    return 50 * level * (level - 1)


def level_for_xp(xp: int) -> int:
    return max(1, int((1 + math.sqrt(1 + max(0, xp) / 12.5)) / 2))


def week_key(day: date) -> str:
    year, week, _ = day.isocalendar()
    return f"{year}-W{week:02d}"


def _parse(ts):
    try:
        return datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def compute_stats(db_path, pet_state: dict | None = None, friends: int = 0, groups: int = 0,
                  today: date | None = None, max_affinity: int = 0, visits_sent: int = 0) -> dict:
    """Everything the level / achievement / Friends features need, from local data only."""
    today = today or date.today()
    pet_state = pet_state or {}
    per_day: dict[str, int] = {}
    minutes_day: dict[str, int] = {}
    early = night = weekend = False
    try:
        con = sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True, timeout=2)
        try:
            rows = con.execute(
                "SELECT day, started_at, ended_at FROM sessions WHERE kind = 'work' AND completed = 1"
            ).fetchall()
        finally:
            con.close()
    except sqlite3.Error as exc:
        logger.debug("stats: no session data (%s)", exc)
        rows = []
    for day, started, ended in rows:
        day = str(day)
        per_day[day] = per_day.get(day, 0) + 1
        start_dt = _parse(started)
        end_dt = _parse(ended)
        minutes = 25
        if start_dt and end_dt:
            minutes = max(0, min(90, int((end_dt - start_dt).total_seconds() // 60)))
        minutes_day[day] = minutes_day.get(day, 0) + minutes
        stamp = end_dt or start_dt
        if stamp:
            if stamp.hour < 8:
                early = True
            if stamp.hour >= 22:
                night = True
            if stamp.weekday() >= 5:
                weekend = True

    total = sum(per_day.values())
    active_days = sorted(d for d, n in per_day.items() if n > 0)
    xp = 20 * total + 10 * len(active_days)
    level = level_for_xp(xp)

    # current streak: consecutive active days ending today (or yesterday if today is still empty)
    streak = 0
    cursor = today if per_day.get(today.isoformat()) else today - timedelta(days=1)
    while per_day.get(cursor.isoformat()):
        streak += 1
        cursor -= timedelta(days=1)
    best = run = 0
    previous = None
    for d in active_days:
        current = date.fromisoformat(d)
        run = run + 1 if previous and (current - previous).days == 1 else 1
        best = max(best, run)
        previous = current

    week = week_key(today)
    week_poms = week_minutes = 0
    for d, n in per_day.items():
        try:
            if week_key(date.fromisoformat(d)) == week:
                week_poms += n
                week_minutes += minutes_day.get(d, 0)
        except ValueError:
            continue
    stats = {
        "total_poms": total,
        "xp": xp,
        "level": level,
        "level_floor": xp_for_level(level),
        "level_next": xp_for_level(level + 1),
        "streak": streak,
        "best_streak": max(best, streak),
        "best_day_poms": max(per_day.values(), default=0),
        "day": today.isoformat(),
        "today_poms": per_day.get(today.isoformat(), 0),
        "today_minutes": minutes_day.get(today.isoformat(), 0),
        "week": week,
        "week_poms": week_poms,
        "week_minutes": week_minutes,
        "early_bird": early,
        "night_owl": night,
        "weekend": weekend,
        "pets_total": int(pet_state.get("pets_total", 0) or 0),
        "tickles_total": int(pet_state.get("tickles_total", 0) or 0),
        "snacks_total": int(pet_state.get("snacks_total", 0) or 0),
        "friends": friends,
        "groups": groups,
        "max_affinity": max_affinity,
        "visits_sent": visits_sent,
    }
    stats["achievements"] = [aid for aid, _sym, cond in ACHIEVEMENTS if cond(stats)]
    return stats


# =============================================================================
# Server client
# =============================================================================

class ApiError(Exception):
    def __init__(self, code: str, status: int = 0):
        super().__init__(code)
        self.code = code
        self.status = status


def api_call(method: str, path: str, body=None, account: dict | None = None, timeout=15) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(API_URL + path, data=data, method=method)
    req.add_header("content-type", "application/json")
    req.add_header("user-agent", "Pips")
    if account:
        req.add_header("authorization", f"Bearer {account['id']}.{account['secret']}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as err:
        try:
            payload = json.loads(err.read().decode("utf-8"))
        except Exception:
            payload = {}
        raise ApiError(payload.get("error", "http_%d" % err.code), err.code) from None
    except (urllib.error.URLError, OSError, ValueError) as err:
        raise ApiError("offline") from err


def default_display_name() -> str:
    raw = os.environ.get("USERNAME", "") or "Friend"
    first = raw.replace(".", "_").split("_")[0]
    return (first[:1].upper() + first[1:])[:24] or "Friend"


# =============================================================================
# Social controller (lives inside the DesktopPet)
# =============================================================================

class Social:
    def __init__(self, pet):
        self.pet = pet
        self.path = Path(pet.base_dir) / "data" / "social.json"
        self.db_path = Path(pet.base_dir) / "data" / "productivity.db"
        self.data = self._load()
        self.results: queue.Queue = queue.Queue()
        self.window = None
        self.board = None
        self.board_at = 0.0
        self.stats = None
        self.busy = False
        self.rooms: dict[str, list] = {}        # "dm:CODE" / "c:ID" -> messages (oldest first)
        self.invites: list = []
        self.history_loaded = False
        self.chat_open_room = None              # room shown in the chat view (fast polling)
        self.visitors = []
        self.leaderboards: dict[str, dict] = {}   # sort -> leaderboard payload
        self.profiles: dict[str, dict] = {}       # code -> {"full": bool, "user": {...}, "at": t}
        self._avatar_jobs: set = set()
        now = time.monotonic()
        self._next_ach = now + 20
        self._next_sync = now + 45
        self._next_board = now + 90
        self._next_inbox = now + 8
        self._inbox_busy = False
        self._last_news = 0.0
        self.arena = None           # /v1/arena payload
        self.arena_open = False     # Arena tab visible -> fast lobby polling + "in arena" presence
        self._next_arena = 0.0
        self.duels: dict = {}       # duel id -> latest /v1/duel view
        self.duel_windows: dict = {}
        self.mod_data = None        # moderator queue (/v1/mod/reports)
        self.admin_data = None      # owner overview (/v1/admin/overview)
        self.new_keys = []          # premium keys generated in this session
        if self.data.get("role") or self.data.get("premium_until"):
            pet.root.after(0, self._apply_owner)

    # ---- persistence ----
    def _load(self) -> dict:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
            tmp.replace(self.path)
        except OSError as exc:
            logger.warning("social: could not save %s: %s", self.path, exc)

    @property
    def enabled(self) -> bool:
        return bool(self.pet.s.get("friends", False)) and bool(self.data.get("id"))

    @property
    def is_owner(self) -> bool:
        return self.data.get("role") == "owner"

    @property
    def is_mod(self) -> bool:
        return self.data.get("role") == "mod"

    @property
    def is_staff(self) -> bool:
        return self.data.get("role") in STAFF_ROLES

    @property
    def premium_until(self) -> int:
        return int(self.data.get("premium_until") or 0)

    @property
    def is_premium(self) -> bool:
        return self.is_staff or self.premium_until > time.time()

    @property
    def muted_until(self) -> int:
        until = int(self.data.get("muted_until") or 0)
        return until if until > time.time() else 0

    def _apply_owner(self):
        """Push role / premium perks into the shop (owner: unlimited, premium + mods: premium items)."""
        shop = getattr(self.pet, "shop", None)
        if shop is not None:
            shop.unlimited = self.is_owner
            shop.premium = self.is_premium
            if shop.premium and shop.add_premium_daily() and pet_shop is not None:
                self.pet.root.after(4000, lambda: self.pet.say(
                    t("premium_daily", n=pet_shop.PREMIUM_DAILY_COINS), duration=5, priority=0))

    @property
    def account(self):
        if self.data.get("id") and self.data.get("secret"):
            return {"id": self.data["id"], "secret": self.data["secret"]}
        return None

    # ---- lookups ----
    def friends(self) -> list:
        return list((self.board or {}).get("friends", []))

    def friend(self, code: str):
        for f in self.friends():
            if f.get("code") == code:
                return f
        return None

    def circles(self) -> list:
        return list((self.board or {}).get("circles", []))

    def circle(self, circle_id: str):
        for c in self.circles():
            if c.get("id") == circle_id:
                return c
        return None

    def room_title(self, room: str) -> str:
        if room.startswith("dm:"):
            f = self.friend(room[3:])
            return f["name"] if f else room[3:]
        c = self.circle(room[2:])
        return c["name"] if c else "?"

    def unread(self, room: str) -> int:
        read = self.data.get("read", {}).get(room, 0)
        return sum(1 for m in self.rooms.get(room, []) if not m.get("mine") and m["id"] > read)

    def total_unread(self) -> int:
        return sum(self.unread(r) for r in self.rooms)

    def mark_read(self, room: str):
        msgs = self.rooms.get(room) or []
        if msgs:
            self.data.setdefault("read", {})[room] = msgs[-1]["id"]
            self.save()

    # ---- coins ----
    def affinity_levels(self) -> int:
        return sum(affinity_level(f.get("affinity", 0))[0] for f in self.friends())

    def wallet(self) -> dict:
        shop = getattr(self.pet, "shop", None)
        if not shop:
            return {"balance": 0, "total": 0, "spent": 0}
        stats = self.stats or self.refresh_stats()
        return shop.wallet(stats, len(self.data.get("unlocked", {})), self.affinity_levels(),
                           int(self.data.get("duel_coins", 0)))

    def my_look(self) -> dict:
        shop = getattr(self.pet, "shop", None)
        if not shop:
            return {}
        look = dict(shop.equipped())
        look["moves"] = shop.moves()
        return look

    def my_gear(self) -> dict:
        shop = getattr(self.pet, "shop", None)
        return shop.gear() if shop else {}

    # ---- stats / achievements ----
    def refresh_stats(self) -> dict:
        board = self.board or {}
        self.stats = compute_stats(
            self.db_path, self.pet.st,
            friends=len(board.get("friends", [])) if self.enabled else 0,
            groups=(len(self.data.get("groups", [])) + len(board.get("circles", []))) if self.enabled else 0,
            max_affinity=max([f.get("affinity", 0) for f in board.get("friends", [])] or [0]) if self.enabled else 0,
            visits_sent=int(self.data.get("visits_sent", 0)))
        if self.is_owner:
            self.stats.update(level=OWNER_LEVEL, xp=OWNER_XP, level_floor=OWNER_XP - 1, level_next=OWNER_XP,
                              achievements=list(ACH_IDS))
        return self.stats

    def check_achievements(self, announce=True) -> list:
        stats = self.refresh_stats()
        unlocked = self.data.setdefault("unlocked", {})
        first_run = not unlocked and not self.data.get("ach_seeded")
        new = [aid for aid in stats["achievements"] if aid not in unlocked]
        if new:
            stamp = date.today().isoformat()
            for aid in new:
                unlocked[aid] = stamp
            self.data["ach_seeded"] = True
            self.save()
            if announce and not first_run:
                aid = new[-1]
                more = len(new) - 1
                text = t("ach_unlocked", name=t("ach_" + aid).split(":")[0])
                if more:
                    text += t("ach_more", n=more)
                if pet_shop is not None:
                    text += t("shop_coins_plus", n=pet_shop.COINS_PER_ACHIEVEMENT * len(new))
                self.pet.set_action("love", 2.0)
                self.pet._spawn("sparkle", 5)
                self.pet._voice("happy")
                self.pet.say(text, duration=6, priority=2, on_click=self.open_window)
        elif not self.data.get("ach_seeded"):
            self.data["ach_seeded"] = True
            self.save()
        self._refresh_window()
        return new

    # ---- background work ----
    def _run(self, kind, fn, *args):
        def worker():
            try:
                result = fn(*args)
                self.results.put((kind, True, result))
            except ApiError as err:
                self.results.put((kind, False, err.code))
            except Exception as exc:  # pragma: no cover - defensive
                logger.exception("social worker failed")
                self.results.put((kind, False, str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    # ---- my profile (v2.6) ----
    PROFILE_DEFAULTS = {"visibility": "public", "bio": "", "info": {}, "status": "auto", "status_text": ""}

    def profile(self) -> dict:
        prof = dict(self.PROFILE_DEFAULTS)
        prof.update(self.data.get("profile") or {})
        if not isinstance(prof.get("info"), dict):
            prof["info"] = {}
        return prof

    def save_profile(self, changes: dict, name: str | None = None):
        prof = self.profile()
        prof.update(changes)
        self.data["profile"] = prof
        if name is not None:
            self.data["name"] = (name.strip() or default_display_name())[:24]
        self.save()
        if self.enabled:
            self.sync()

    def avatar_dir(self) -> Path:
        return Path(self.pet.base_dir) / "data" / "avatars"

    def my_avatar_path(self):
        path = self.avatar_dir() / "me.png"
        return path if self.data.get("avatar_v") and path.exists() else None

    def set_avatar_from_file(self, src: str) -> str:
        """Crop + resize a picture to a round 96px PNG; returns '' or an error code."""
        try:
            from PIL import Image, ImageDraw
        except ImportError:
            return "no_pillow"
        try:
            img = Image.open(src).convert("RGBA")
        except Exception:
            return "bad_image"
        side = min(img.size)
        left = (img.width - side) // 2
        top = (img.height - side) // 2
        img = img.crop((left, top, left + side, top + side)).resize((96, 96), Image.LANCZOS)
        mask = Image.new("L", (96 * 4, 96 * 4), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, 96 * 4 - 1, 96 * 4 - 1], fill=255)
        img.putalpha(mask.resize((96, 96), Image.LANCZOS))
        self.avatar_dir().mkdir(parents=True, exist_ok=True)
        out = self.avatar_dir() / "me.png"
        img.save(out, "PNG", optimize=True)
        data = base64.b64encode(out.read_bytes()).decode("ascii")
        if len(data) > 78000:
            img.quantize(colors=128).save(out, "PNG", optimize=True)
            data = base64.b64encode(out.read_bytes()).decode("ascii")
        self.data["avatar_v"] = int(time.time())
        self.save()
        if self.enabled:
            self._act("avatar_set", "/v1/avatar", {"data": data})
        return ""

    def clear_avatar(self):
        self.data["avatar_v"] = 0
        self.save()
        try:
            (self.avatar_dir() / "me.png").unlink()
        except OSError:
            pass
        if self.enabled:
            self._act("avatar_set", "/v1/avatar", {"data": ""})

    def avatar_path(self, code: str, version: int):
        """Cached avatar for a user (downloads it in the background when missing)."""
        if not version or not code:
            return None
        if code == self.data.get("code"):
            return self.my_avatar_path()
        path = self.avatar_dir() / f"{code}_{int(version)}.png"
        if path.exists():
            return path
        if self.enabled and (code, version) not in self._avatar_jobs:
            self._avatar_jobs.add((code, version))
            self._run("avatar", self._fetch_avatar, code, int(version))
        return None

    def _fetch_avatar(self, code, version):
        result = api_call("GET", f"/v1/avatar?code={code}", None, self.account)
        raw = base64.b64decode(result.get("data", ""))
        if not raw.startswith(b"\x89PNG"):
            raise ApiError("bad_image")
        folder = self.avatar_dir()
        folder.mkdir(parents=True, exist_ok=True)
        for old in folder.glob(f"{code}_*.png"):
            try:
                old.unlink()
            except OSError:
                pass
        (folder / f"{code}_{version}.png").write_bytes(raw)
        return {"code": code}

    # ---- leaderboard / profiles / requests / labels (v2.6) ----
    def load_leaderboard(self, sort="xp"):
        if self.enabled:
            self._run("leaderboard", api_call, "GET", f"/v1/leaderboard?sort={sort}", None, self.account)

    def view_user(self, code: str):
        if self.enabled:
            self._run("user", api_call, "GET", f"/v1/user?code={code}", None, self.account)

    def respond_request(self, code: str, accept: bool):
        board = self.board or {}
        board["requests"] = [r for r in board.get("requests", []) if r.get("code") != code]
        self._act("request_answered", "/v1/friends/respond", {"code": code, "accept": bool(accept)})

    def cancel_request(self, code: str):
        self._act("request_cancelled", "/v1/friends/cancel", {"code": code})

    def set_label(self, code: str, label: str):
        self._act("label_set", "/v1/friends/label", {"code": code, "label": label})

    # ---- reports, moderation, premium (v2.7) ----
    def report_user(self, code: str, reason: str):
        if self.enabled:
            self._run("reported", api_call, "POST", "/v1/report", {"code": code, "reason": reason[:200]}, self.account)

    def load_mod(self):
        if self.enabled and self.is_staff:
            self._run("mod", api_call, "GET", "/v1/mod/reports", None, self.account)

    def mod_action(self, code: str, action: str, **extra):
        body = {"code": code, "action": action}
        body.update(extra)
        self._act("mod_done", "/v1/mod/action", body)

    def load_admin(self):
        if self.enabled and self.is_owner:
            self._run("admin", api_call, "GET", "/v1/admin/overview", None, self.account)

    def set_role(self, code: str, role: str):
        self._act("admin_done", "/v1/admin/role", {"code": code, "role": role})

    def give_premium(self, code: str, days: int):
        self._act("admin_done", "/v1/admin/premium", {"code": code, "days": int(days)})

    def make_keys(self, days: int, count: int = 1, note: str = ""):
        if self.enabled and self.is_owner:
            self._run("keys", api_call, "POST", "/v1/admin/keys",
                      {"days": int(days), "count": int(count), "note": note[:60]}, self.account)

    def redeem_key(self, key: str):
        self._act("redeemed", "/v1/premium/redeem", {"key": key.strip().upper()})

    # ---- arena & duels (v2.8) ----
    def load_arena(self, here=False):
        if self.enabled:
            self._run("arena", api_call, "GET", "/v1/arena" + ("?here=1" if here else ""), None, self.account)

    def challenge(self, code: str):
        if self.enabled:
            self._run("duel_challenged", api_call, "POST", "/v1/duel/challenge",
                      {"code": code, "gear": self.my_gear()}, self.account)

    def respond_duel(self, duel_id: str, accept: bool):
        if self.enabled:
            self._run("duel_responded", api_call, "POST", "/v1/duel/respond",
                      {"id": duel_id, "accept": bool(accept), "gear": self.my_gear()}, self.account)

    def quick_duel(self, code: str):
        if self.enabled:
            self._run("duel", api_call, "POST", "/v1/duel/quick", {"code": code, "gear": self.my_gear()}, self.account)

    def load_duel(self, duel_id: str):
        if self.enabled:
            self._run("duel", api_call, "GET", f"/v1/duel?id={duel_id}", None, self.account)

    def duel_act(self, duel_id: str, round_no: int, action: str):
        if self.enabled:
            self._run("duel", api_call, "POST", "/v1/duel/act",
                      {"id": duel_id, "round": int(round_no), "action": action}, self.account)

    def forfeit_duel(self, duel_id: str):
        if self.enabled:
            self._run("duel_forfeit", api_call, "POST", "/v1/duel/forfeit", {"id": duel_id}, self.account)

    def open_duel(self, duel_id: str, spectate: bool = False):
        import arena_ui
        win = self.duel_windows.get(duel_id)
        if win and win.alive():
            win.win.deiconify()
            win.win.lift()
            return
        self.duel_windows[duel_id] = arena_ui.DuelWindow(self, duel_id, spectate=spectate)

    def _notify_duels(self, duels: list):
        notified = set(self.data.get("notified_duels", []))
        for d in duels or []:
            if d.get("id") in notified:
                continue
            notified.add(d["id"])
            self.pet.set_action("hop", 0.55)
            self.pet._voice("greet")
            self.pet.say(t("duel_incoming", name=d.get("from", {}).get("name", "?")), duration=12, priority=2,
                         on_click=lambda: self.open_window("arena"))
        self.data["notified_duels"] = sorted(notified)[-50:]

    def _take_notices(self, notices: list):
        """React to moderator / owner notices (warnings, mutes, role and premium changes)."""
        seen = int(self.data.get("notice_seen", 0))
        fresh = [n for n in notices or [] if int(n.get("id", 0)) > seen]
        if not fresh:
            return
        self.data["notice_seen"] = max(int(n["id"]) for n in fresh)
        resync = False
        for n in fresh:
            kind = n.get("kind")
            body = n.get("body", "")
            if kind == "warn":
                self.data["last_warning"] = {"text": body, "at": n.get("created_at", 0)}
                self.pet.set_action("worried", 3.0)
                self.pet.say(t("notice_warn", text=body), duration=12, priority=2)
            elif kind == "mute":
                stamp = datetime.fromtimestamp(int(body or 0)).strftime("%d %b %H:%M") if body.isdigit() else "?"
                self.pet.set_action("worried", 3.0)
                self.pet.say(t("notice_mute", time=stamp), duration=10, priority=2)
            elif kind == "unmute":
                self.pet.say(t("notice_unmute"), duration=6, priority=1)
            elif kind == "cleared":
                prof = self.profile()
                prof.update(bio="", status_text="", info={})
                self.data["profile"] = prof
                self.data.pop("avatar_v", None)
                resync = True
                self.pet.say(t("notice_cleared"), duration=10, priority=2)
            elif kind == "renamed":
                self.data["name"] = "Pips friend"
                resync = True
                self.pet.say(t("notice_renamed"), duration=10, priority=2)
            elif kind == "mod_on":
                self.pet.set_action("cheer", 1.6)
                self.pet._spawn("sparkle", 6)
                self.pet.say(t("mod_welcome"), duration=10, priority=2, on_click=lambda: self.open_window("mod"))
            elif kind == "mod_off":
                self.pet.say(t("mod_removed"), duration=7, priority=1)
            elif kind == "premium_on":
                until = int(body) if str(body).isdigit() else 0
                self.pet.set_action("love", 2.0)
                self.pet._spawn("sparkle", 8)
                self.pet._voice("happy")
                self.pet.say(t("premium_welcome", until=self.premium_text(until)), duration=10, priority=2,
                             on_click=lambda: self.open_window("profile"))
            elif kind == "premium_off":
                self.pet.say(t("premium_ended"), duration=8, priority=1)
        self.save()
        if resync:
            self.sync()

    @staticmethod
    def premium_text(until: int) -> str:
        if until >= PREMIUM_FOREVER:
            return t("premium_forever")
        if until <= 0:
            return "-"
        return datetime.fromtimestamp(until).strftime("%d %b %Y")

    def requests(self) -> list:
        return list((self.board or {}).get("requests", []))

    def sent_requests(self) -> set:
        return set((self.board or {}).get("sent", []))

    def _notify_requests(self):
        notified = set(self.data.get("notified_requests", []))
        for req in self.requests():
            if req["code"] not in notified:
                notified.add(req["code"])
                self.pet.set_action("hop", 0.55)
                self.pet.say(t("req_new", name=req.get("name", "?")), duration=7, priority=1,
                             on_click=lambda: self.open_window("friends"))
        self.data["notified_requests"] = sorted(notified)[-100:]

    def _profile_payload(self) -> dict:
        stats = self.stats or self.refresh_stats()
        unlocked = list(self.data.get("unlocked", {}).keys())
        prof = self.profile()
        return {
            "visibility": prof["visibility"],
            "bio": prof["bio"],
            "info": prof["info"],
            "status": prof["status"],
            "status_text": prof["status_text"],
            "name": self.data.get("name") or default_display_name(),
            "species": self.pet.s.get("species", "cat"),
            "color": self.pet.s.get("color", "#ffc78f"),
            "level": stats["level"],
            "xp": stats["xp"],
            "streak": stats["streak"],
            "day": stats["day"],
            "today_poms": stats["today_poms"],
            "today_minutes": stats["today_minutes"],
            "week": stats["week"],
            "week_poms": stats["week_poms"],
            "week_minutes": stats["week_minutes"],
            "achievements": unlocked,
            "mood": self.pet.mood(),
            "look": self.my_look(),
            "gear": self.my_gear(),
        }

    def _board_now(self, account=None):
        stats = self.stats or self.refresh_stats()
        return api_call("GET", f"/v1/board?day={stats['day']}&week={stats['week']}", None,
                        account or self.account)

    def _sync_and_board(self, payload, account):
        api_call("POST", "/v1/profile", payload, account)
        return self._board_now(account)

    def sync(self):
        if not self.enabled:
            return
        self.refresh_stats()
        self._run("board", self._sync_and_board, self._profile_payload(), self.account)

    def enable(self, name: str):
        name = (name or "").strip()[:24] or default_display_name()
        self.data["name"] = name
        self.save()
        self.pet.update_setting("friends", True)
        if self.data.get("id"):
            self.sync()
            return
        self.refresh_stats()
        body = {"name": name, "species": self.pet.s.get("species", "cat"),
                "color": self.pet.s.get("color", "#ffc78f")}
        self.busy = True
        self._run("register", self._register_then_sync, body)

    def _register_then_sync(self, body):
        account = api_call("POST", "/v1/register", body)
        self.results.put(("account", True, account))
        acc = {"id": account["id"], "secret": account["secret"]}
        api_call("POST", "/v1/profile", dict(self._profile_payload()), acc)
        return self._board_now(acc)

    def disable_and_delete(self):
        account = self.account
        self.pet.update_setting("friends", False)
        self.board = None
        self.rooms = {}
        self.invites = []
        self.history_loaded = False
        if account:
            self._run("deleted", api_call, "DELETE", "/v1/me", None, account)
        self.leaderboards = {}
        self.profiles = {}
        for key in ("id", "secret", "code", "groups", "read", "seen_id", "notified_invites", "notified_requests",
                    "role", "premium_until", "muted_until", "notice_seen"):
            self.data.pop(key, None)
        self.mod_data = None
        self.admin_data = None
        self._apply_owner()
        self.save()
        self._refresh_window()

    def _then_board(self, method, path, body):
        result = api_call(method, path, body, self.account)
        board = self._board_now()
        board["_result"] = result
        return board

    def _act(self, kind, path, body):
        if self.enabled:
            self._run(kind, self._then_board, "POST", path, body)

    def add_friend(self, code: str):
        self._act("friend_added", "/v1/friends/add", {"code": code.strip().upper()})

    def remove_friend(self, code: str):
        self._act("friend_removed", "/v1/friends/remove", {"code": code})

    def join_group(self, group: str):
        self._act("group_joined", "/v1/groups/join", {"group": group})

    def leave_group(self, group: str):
        self._act("group_left", "/v1/groups/leave", {"group": group})

    def create_circle(self, name: str):
        self._act("circle_created", "/v1/circles/create", {"name": name})

    def invite_to_circle(self, circle_id: str, code: str):
        self._act("circle_invited", "/v1/circles/invite", {"circle": circle_id, "code": code})

    def respond_invite(self, circle_id: str, accept: bool):
        self.invites = [i for i in self.invites if i.get("circle") != circle_id]
        self._act("circle_joined" if accept else "circle_declined", "/v1/circles/respond",
                  {"circle": circle_id, "accept": bool(accept)})

    def leave_circle(self, circle_id: str):
        self._act("circle_left", "/v1/circles/leave", {"circle": circle_id})

    def kick_from_circle(self, circle_id: str, code: str):
        self._act("circle_kicked", "/v1/circles/kick", {"circle": circle_id, "code": code})

    # ---- chat & interactions ----
    def send(self, room: str, kind: str = "text", body: str = ""):
        if not self.enabled:
            return
        shop = getattr(self.pet, "shop", None)
        if kind == "visit" and shop and shop.moves() and not body:
            body = random.choice(shop.moves())       # my pet shows off a move when it arrives
        if shop:
            shop.add_interaction_bonus()
        payload = {"kind": kind, "body": body[:500]}
        if room.startswith("dm:"):
            payload["to"] = room[3:]
        else:
            payload["circle"] = room[2:]
        if kind == "visit":
            self.data["visits_sent"] = int(self.data.get("visits_sent", 0)) + 1
            self.save()
        self._run("sent", self._send_then_inbox, payload, room, kind)

    def _send_then_inbox(self, payload, room, kind):
        api_call("POST", "/v1/send", payload, self.account)
        result = api_call("GET", f"/v1/inbox?since={self._since()}", None, self.account)
        result["_room"] = room
        result["_kind"] = kind
        return result

    def _since(self) -> int:
        return max([m["id"] for msgs in self.rooms.values() for m in msgs] or [0]) if self.history_loaded else 0

    def _idle_flag(self) -> str:
        try:
            import pet as pet_mod
            return "1" if pet_mod.user_idle_seconds() > IDLE_AWAY_S else "0"
        except Exception:
            return "0"

    def poll_inbox(self):
        if not self.enabled or self._inbox_busy:
            return
        self._inbox_busy = True
        self._run("inbox", api_call, "GET", f"/v1/inbox?since={self._since()}&idle={self._idle_flag()}", None,
                  self.account)

    def _take_inbox(self, result, initial=False):
        if isinstance(result, dict) and result.get("duels"):
            self._notify_duels(result["duels"])
        seen = int(self.data.get("seen_id", 0))
        fresh = []
        for m in result.get("messages", []):
            room = m.get("room")
            if not room:
                continue
            msgs = self.rooms.setdefault(room, [])
            if msgs and msgs[-1]["id"] >= m["id"]:
                continue
            msgs.append(m)
            if len(msgs) > MAX_ROOM_HISTORY:
                del msgs[: len(msgs) - MAX_ROOM_HISTORY]
            if m["id"] > seen and not m.get("mine"):
                fresh.append(m)
        top = max([m["id"] for m in result.get("messages", [])] or [seen])
        if top > seen:
            self.data["seen_id"] = top
            self.save()
        if self.chat_open_room:
            self.mark_read(self.chat_open_room)
        self.invites = result.get("invites", self.invites)
        self._notify_invites()
        # first load after start: only react to things that arrived very recently
        cutoff = time.time() - (10 * 60 if initial else 24 * 3600)
        for m in fresh[-5:]:
            if m.get("at", 0) >= cutoff:
                self._react_to(m)

    def _notify_invites(self):
        notified = set(self.data.get("notified_invites", []))
        for inv in self.invites:
            if inv["circle"] not in notified:
                notified.add(inv["circle"])
                self.pet.say(t("cir_invited_you", name=inv.get("by", "?"), group=inv.get("name", "?")),
                             duration=7, priority=1, on_click=lambda: self.open_window("groups"))
        self.data["notified_invites"] = sorted(notified)[-50:]
        self.save()

    def _quiet(self) -> bool:
        return bool(self.pet.focus and self.pet.s.get("quiet_focus", True))

    def _react_to(self, m):
        """Your pet reacts to an incoming message / interaction."""
        pet = self.pet
        who = (m.get("from") or {}).get("name", "?")
        kind = m.get("kind", "text")
        room = m.get("room", "")
        open_chat = lambda r=room: self.open_window("chat", room=r)
        if self.window and self.window.alive() and self.chat_open_room == room and kind == "text":
            return  # you're looking at it already
        pet_name = pet.s.get("name", "Pip")
        if kind == "text":
            body = m.get("body", "")
            body = body if len(body) <= 80 else body[:77] + "\u2026"
            where = "" if room.startswith("dm:") else " (" + self.room_title(room) + ")"
            pet.say(t("chat_bubble", name=who + where, text=body), duration=7,
                    priority=0 if self._quiet() else 1, on_click=open_chat)
            if not self._quiet():
                pet.set_action("hop", 0.55)
                pet._voice("greet")
            return
        if kind == "wave":
            pet.set_action("hop", 0.55)
            pet._voice("greet")
        elif kind == "pet":
            pet.set_action("petted", 1.8)
            pet._spawn("heart", 3)
            pet._bump("happiness", 3)
            pet._voice("pet")
        elif kind == "snack":
            pet.set_action("eat", 2.0)
            pet._spawn("crumb", 4)
            pet._bump("fullness", 10)
            pet._bump("happiness", 4)
            pet._voice("eat")
        elif kind in ("highfive", "cheer"):
            pet.set_action("cheer", 1.4)
            pet._spawn("sparkle", 4)
            pet._voice("happy")
        elif kind == "visit":
            who_info = dict(m.get("from") or {})
            if m.get("body"):
                who_info["trick"] = m["body"]
            self.start_visit(who_info)
            pet._voice("greet")
        group = "" if room.startswith("dm:") else self.room_title(room)
        pet.say(t("ix_in_" + kind, name=who, pet=pet_name, group=group), duration=6, priority=1, on_click=open_chat)

    def start_visit(self, who: dict):
        if len(self.visitors) >= 2 or not self.pet.visible or self.pet.fs_hidden:
            return
        try:
            self.visitors.append(VisitorPet(self, who))
        except Exception:
            logger.exception("visit failed")

    # ---- main-thread pump ----
    def poll(self):
        while True:
            try:
                kind, ok, payload = self.results.get_nowait()
            except queue.Empty:
                break
            try:
                self._handle(kind, ok, payload)
            except Exception:
                logger.exception("social: handling %s failed", kind)

    def _handle(self, kind, ok, payload):
        if kind == "account":
            if ok:
                self.data.update({"id": payload["id"], "secret": payload["secret"], "code": payload["code"]})
                self.save()
            return
        if kind == "register":
            self.busy = False
        if kind == "inbox":
            self._inbox_busy = False
        if not ok:
            if payload == "unauthorized" and kind != "deleted":
                logger.warning("social: account no longer valid - turning Friends off")
                for key in ("id", "secret", "code", "groups"):
                    self.data.pop(key, None)
                self.save()
                self.pet.update_setting("friends", False)
            if kind not in ("inbox", "avatar", "leaderboard", "arena", "duel") and self.window and self.window.alive():
                self.window.show_error(payload)
            return
        if not self.enabled:
            return  # late reply after Friends was turned off
        if kind == "inbox" or (kind == "sent" and isinstance(payload, dict)):
            initial = not self.history_loaded
            self.history_loaded = True
            self._take_inbox(payload, initial=initial)
            if kind == "sent":
                pet = self.pet
                pet.set_action("hop", 0.55)
                if payload.get("_kind") in INTERACTIONS:
                    pet.say(t("ix_sent_" + payload["_kind"], name=self.room_title(payload["_room"])),
                            duration=3, priority=1)
                    if payload["_kind"] == "visit":
                        self.check_achievements()
        if isinstance(payload, dict) and "friends" in payload:
            self._take_board(payload)
        if kind == "arena":
            self.arena = dict(payload, _at=time.time())
            me = payload.get("me", {})
            self.data["duel_coins"] = int(me.get("duel_coins", self.data.get("duel_coins", 0)))
            self.data["rating"] = int(me.get("rating", 1000))
            self._notify_duels([{"id": c["id"], "from": c["from"]} for c in payload.get("incoming", [])])
            active = me.get("active")
            if active and active not in self.duel_windows:
                self.open_duel(active)
        elif kind == "duel":
            duel = payload.get("duel", {})
            if duel.get("id"):
                first = duel["id"] not in self.duels
                self.duels[duel["id"]] = dict(duel, _at=time.time())
                if duel.get("result", {}).get("coins"):
                    side = duel.get("mine")
                    if side:
                        self.load_arena()
                if first and duel.get("mode") == "quick" and duel["id"] not in self.duel_windows:
                    self.open_duel(duel["id"])
                win = self.duel_windows.get(duel["id"])
                if win and win.alive():
                    win.update_state()
        elif kind == "duel_challenged":
            self.pet.set_action("hop", 0.55)
            self.pet.say(t("duel_sent"), duration=5, priority=1)
            self.load_arena()
        elif kind == "duel_responded":
            if payload.get("status") == "active" and payload.get("id"):
                self.open_duel(payload["id"])
            self.load_arena()
        elif kind == "duel_forfeit":
            self.load_arena()
        if kind == "mod":
            self.mod_data = dict(payload, _at=time.time())
        elif kind == "admin":
            self.admin_data = dict(payload, _at=time.time())
        elif kind == "keys":
            self.new_keys = list(payload.get("keys", [])) + self.new_keys
            self.load_admin()
        elif kind == "reported":
            self.pet.say(t("report_sent"), duration=5, priority=1)
        elif kind == "mod_done":
            self.pet.set_action("hop", 0.55)
            if self.window and self.window.alive():
                self.window.status.config(text=t("mod_done"))
            self.load_mod()
            self.load_admin()
            self.profiles.pop(payload.get("_result", {}).get("user", {}).get("code", ""), None)
            self._refresh_social_views()
        elif kind == "admin_done":
            self.load_admin()
            self._refresh_social_views()
        elif kind == "redeemed":
            self._refresh_window()
        if kind == "leaderboard":
            self.leaderboards[payload.get("sort", "xp")] = dict(payload, _at=time.time())
        elif kind == "user":
            user = payload.get("user", {})
            self.profiles[user.get("code", "")] = {"full": payload.get("full"), "user": user, "at": time.time()}
        elif kind == "avatar":
            pass
        if kind == "friend_added":
            result = payload.get("_result", {})
            friend = result.get("friend", {})
            if result.get("status") == "requested":
                self.pet.set_action("hop", 0.55)
                self.pet.say(t("req_sent", name=friend.get("name", "?")), duration=4, priority=1)
            else:
                self.pet.set_action("cheer", 1.4)
                self.pet._voice("greet")
                self.pet.say(t("fr_added", name=friend.get("name", "?")), duration=4, priority=1)
                self.check_achievements()
            self._refresh_social_views(friend.get("code"))
        elif kind == "request_answered":
            result = payload.get("_result", {})
            if result.get("accepted"):
                self.pet.set_action("cheer", 1.4)
                self.pet._voice("greet")
                self.pet.say(t("fr_added", name=result.get("friend", {}).get("name", "?")), duration=4, priority=1)
                self.check_achievements()
        elif kind in ("label_set", "request_cancelled", "friend_removed"):
            self._refresh_social_views()
        elif kind in ("group_joined", "circle_joined", "circle_created"):
            self.check_achievements()
        elif kind == "circle_invited":
            self.pet.say(t("cir_invite_sent", name=payload.get("_result", {}).get("invited", "?")),
                         duration=3, priority=1)
        self._refresh_window()

    def _take_board(self, board):
        if not self.enabled:
            return
        old = {f["code"]: f for f in (self.board or {}).get("friends", [])}
        self.board = board
        self.board_at = time.time()
        self.data["code"] = board.get("me", {}).get("code", self.data.get("code"))
        me = board.get("me", {})
        role = me.get("role", "")
        was_premium = self.is_premium
        self.data["premium_until"] = int(me.get("premium_until") or 0)
        if "duel_coins" in me:
            self.data["duel_coins"] = int(me.get("duel_coins") or 0)
            self.data["rating"] = int(me.get("rating") or 1000)
        self.data["muted_until"] = int(me.get("muted_until") or 0)
        if role != self.data.get("role", ""):
            self.data["role"] = role
            if role == "owner":
                self.pet.set_action("cheer", 1.6)
                self.pet._spawn("sparkle", 8)
                self.pet.say(t("owner_welcome"), duration=7, priority=2)
                self.check_achievements(announce=False)
        if role != getattr(self, "_applied_role", None) or was_premium != self.is_premium:
            self._applied_role = role
            self._apply_owner()
        self._take_notices(board.get("notices", []))
        self.data["groups"] = [g["code"] for g in board.get("groups", [])]
        self.invites = board.get("invites", self.invites)
        self._notify_requests()
        self.save()
        self._notify_invites()
        if old and self.pet.s.get("chatty", True) and time.monotonic() - self._last_news > FRIEND_NEWS_GAP_S:
            for friend in board.get("friends", []):
                before = old.get(friend["code"])
                if before and friend["today_poms"] > before["today_poms"]:
                    self._last_news = time.monotonic()
                    self.pet.say(t("fr_news", name=friend["name"], n=friend["today_poms"]),
                                 duration=5, priority=0, on_click=self.open_window)
                    break
                if before and affinity_level(friend.get("affinity", 0))[0] > affinity_level(before.get("affinity", 0))[0]:
                    self._last_news = time.monotonic()
                    self.pet.set_action("love", 2.0)
                    self.pet.say(t("aff_level_up", name=friend["name"],
                                   level=t(affinity_level(friend["affinity"])[1])),
                                 duration=6, priority=1, on_click=self.open_window)
                    break

    def _refresh_window(self):
        if self.window and self.window.alive():
            self.window.refresh()

    def _refresh_social_views(self, code=None):
        """Re-fetch whatever the open window shows after a relationship change."""
        win = self.window
        if not (win and win.alive()):
            return
        if getattr(win, "tab", "") == "ranks":
            self.load_leaderboard(getattr(win, "rank_sort", "xp"))
        viewing = getattr(win, "viewing", None)
        if viewing:
            self.view_user(viewing)

    def tick(self, now: float):
        self.poll()
        self.visitors = [v for v in self.visitors if v.alive]
        if now >= self._next_ach:
            self._next_ach = now + ACH_CHECK_EVERY_S
            try:
                self.check_achievements()
            except Exception:
                logger.exception("achievement check failed")
        if not self.enabled:
            return
        if now >= self._next_sync:
            self._next_sync = now + SYNC_EVERY_S
            self._next_board = now + BOARD_EVERY_S
            self.sync()
        elif now >= self._next_board:
            self._next_board = now + BOARD_EVERY_S
            self.sync()
        if self.arena_open and self.window and self.window.alive() and now >= self._next_arena:
            self._next_arena = now + 3
            self.load_arena(here=True)
        fast = self.window and self.window.alive() and self.chat_open_room
        if now >= self._next_inbox:
            self._next_inbox = now + (INBOX_FAST_S if fast else INBOX_EVERY_S)
            self.poll_inbox()

    def on_pomodoro(self):
        try:
            self.check_achievements()
        except Exception:
            logger.exception("achievement check failed")
        if self.enabled:
            self._next_sync = time.monotonic() + SYNC_EVERY_S
            self.sync()

    # ---- window ----
    def open_window(self, tab=None, room=None):
        import social_ui
        if self.window and self.window.alive():
            self.window.win.deiconify()
            self.window.win.lift()
        else:
            self.window = social_ui.FriendsWindow(self)
        if tab:
            self.window.show_tab(tab, room=room)
        else:
            self.window.refresh()
        if self.enabled and time.time() - self.board_at > 30:
            self.sync()
        if self.enabled:
            self.poll_inbox()

    def close(self):
        if self.window and self.window.alive():
            self.window.close()
        for v in self.visitors:
            v.leave(now=True)
        for win in list(self.duel_windows.values()):
            if win.alive():
                win.close()


# =============================================================================
# A friend's pet visiting your desktop
# =============================================================================

class VisitorPet:
    DURATION_S = 25.0

    def __init__(self, social: Social, who: dict):
        import pet as pet_mod  # late import: pet imports social

        self.pet_mod = pet_mod
        self.social = social
        self.host = social.pet
        self.who = who
        self.alive = True
        host = self.host
        self.size = int(host.size * 0.9)
        self.W = int(self.size * 2.0)
        self.H = int(self.size * 2.0)
        species = who.get("species") if who.get("species") in pet_mod.SPECIES else "cat"
        self.props = pet_shop.clean_look(who.get("look")) if pet_shop is not None else {}
        self.trick = who.get("trick") if pet_shop is not None and who.get("trick") in pet_shop.MOVES else None
        self.trick_t0 = None
        self.look_base = pet_mod.default_look({"species": species,
                                               "color": who.get("color") or pet_mod.SPECIES[species]["color"]})
        self.win = tk.Toplevel(host.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.configure(bg=pet_mod.KEY)
        try:
            self.win.attributes("-transparentcolor", pet_mod.KEY)
        except tk.TclError:
            pass
        self.cv = tk.Canvas(self.win, width=self.W, height=self.H, bg=pet_mod.KEY, highlightthickness=0,
                            cursor="hand2")
        self.cv.pack()
        self.cv.bind("<Button-1>", self._on_click)
        wx, wy, w, h = host.window_rect()
        screen_w = host.root.winfo_screenwidth()
        self.side = -1 if wx + w + self.W > screen_w - 10 else 1   # which side of your pet
        self.floor = wy + h
        self.target_x = (wx - self.W + 10) if self.side < 0 else (wx + w - 10)
        self.x = float(self.target_x + self.side * 160)
        self.t0 = time.monotonic()
        self.hop_until = self.t0 + 1.5
        self.hearts = []
        self.leaving = False
        self._frame()

    def _on_click(self, _event):
        self.hop_until = time.monotonic() + 0.8
        self.hearts.append([self.W / 2, self.H - self.size * 1.1, time.monotonic()])

    def leave(self, now=False):
        if now:
            self.alive = False
            try:
                self.win.destroy()
            except tk.TclError:
                pass
        else:
            self.leaving = True

    def _frame(self):
        if not self.alive:
            return
        now = time.monotonic()
        age = now - self.t0
        if age > self.DURATION_S:
            self.leaving = True
        goal = self.target_x + (self.side * 220 if self.leaving else 0)
        walking = abs(goal - self.x) > 2
        if walking:
            step = 3.2 if self.leaving else 2.6
            self.x += step if goal > self.x else -step
        elif self.leaving:
            self.leave(now=True)
            return
        look = dict(self.look_base)
        look["t"] = now
        look["facing"] = (1 if goal > self.x else -1) if walking else -self.side
        phase = now * 9
        if walking:
            look["foot_l"] = math.sin(phase) * 3
            look["foot_r"] = -math.sin(phase) * 3
            look["hop"] = abs(math.sin(phase)) * 2
        if now < self.hop_until:
            look["hop"] = abs(math.sin((self.hop_until - now) * 9)) * 10
            look["mouth"] = "open"
        else:
            look["mouth"] = "smile"
        if int(age * 2) % 9 == 0 and not walking:
            look["eyes"] = "happy"
        if self.look_base["species"] in self.pet_mod.SPECIES and \
                self.pet_mod.SPECIES[self.look_base["species"]].get("cat") == "air":
            look["flap"] = math.sin(now * 14)
            look["hover"] = 6 + math.sin(now * 2) * 3
        if self.trick and not walking and not self.leaving and age > 2.5:
            if self.trick_t0 is None:
                self.trick_t0 = now
            span = min(pet_shop.MOVES[self.trick][1], 4.0)
            p = (now - self.trick_t0) / span
            if p <= 1.0 and self.trick not in ("spider", "moonwalk"):
                pet_shop.trick_pose(look, self.trick, p, now)
            elif p <= 1.0:
                pet_shop.trick_pose(look, "dance", p, now)
        if not walking and age > 3 and int(age) % 5 == 0 and not self.hearts:
            self.hearts.append([self.W / 2 + random.uniform(-8, 8), self.H - self.size * 1.1, now])
        try:
            self.cv.delete("all")
            if self.props:
                pet_shop.draw_back_props(self.cv, self.pet_mod.body_geometry(self.W / 2, self.H - 4, self.size, look),
                                         self.props, now)
            geo = self.pet_mod.draw_pet(self.cv, self.W / 2, self.H - 4, self.size, look)
            if self.props:
                pet_shop.draw_front_props(self.cv, geo, self.props, now)
            name = (self.who.get("name") or "?")[:16]
            label_y = self.H - self.size * 1.25 - look.get("hop", 0) - look.get("hover", 0)
            self.cv.create_text(self.W / 2, max(8, label_y), text=name, font=("Segoe UI", 8, "bold"),
                                fill="#8b1a1a")
            keep = []
            for hx, hy, born in self.hearts:
                life = now - born
                if life < 1.6:
                    self.cv.create_text(hx, hy - life * 25, text="\u2665", fill="#ff6b8b",
                                        font=("Segoe UI Symbol", 12))
                    keep.append([hx, hy, born])
            self.hearts = keep
            self.win.geometry("%dx%d+%d+%d" % (self.W, self.H, int(self.x), int(self.floor - self.H)))
        except tk.TclError:
            self.alive = False
            return
        self.host.root.after(40, self._frame)

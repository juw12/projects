"""
social.py - levels, achievements and Friends for Pips.

* Levels / XP / streak / achievements are computed locally from the pomodoro
  history (data/productivity.db) and the pet state - they work offline.
* Friends (opt-in, off by default) syncs a tiny public profile to the Pips
  Friends server (Cloudflare Worker + D1) so friends and teams can see each
  other's level, streak and pomodoro counts. Shared: display name, pet animal +
  colour, level, XP, streak, today's / this week's pomodoros and focus minutes,
  achievements, pet mood. Never: app names, window titles, scores, files.

v2 adds chat (friends + groups), private groups ("circles") with invites,
affinity (friendship level that grows with every interaction) and pet
interactions: wave, pet, snack, high five and pet visits (the friend's pet
walks onto your desktop for a moment).

Account (id + secret + friend code) lives in data/social.json on this PC.
The window lives in social_ui.py. All user-facing text comes from i18n.py.
"""

from __future__ import annotations

import json
import logging
import math
import os
import queue
import random

try:
    import pet_shop
except ImportError:  # pragma: no cover
    pet_shop = None
import sqlite3
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

try:
    from i18n import t
except ImportError:  # pragma: no cover
    def t(key, lang=None, **kwargs):
        return key.format(**kwargs) if kwargs else key

logger = logging.getLogger("social")

API_URL = "https://pips-friends.juwenmondial.workers.dev"
SYNC_EVERY_S = 10 * 60
BOARD_EVERY_S = 15 * 60
ACH_CHECK_EVERY_S = 5 * 60
FRIEND_NEWS_GAP_S = 30 * 60
INBOX_EVERY_S = 45
INBOX_FAST_S = 5          # while a chat is open
MAX_ROOM_HISTORY = 150

# affinity (friendship) levels: (points needed, i18n key)
AFFINITY_LEVELS = [(0, "aff_acq"), (20, "aff_buddy"), (60, "aff_good"), (150, "aff_close"),
                   (300, "aff_best"), (600, "aff_soul")]
INTERACTIONS = ("wave", "pet", "snack", "highfive", "visit")
INTERACTION_SYMBOL = {"wave": "\u270b", "pet": "\u2665", "snack": "\u2615", "highfive": "\u2605",
                      "visit": "\u2302", "cheer": "\u266b"}


def affinity_level(points: int):
    """-> (level index 0.., i18n key, points of this level, points of next level or None)."""
    points = max(0, int(points or 0))
    index = 0
    for i, (need, _key) in enumerate(AFFINITY_LEVELS):
        if points >= need:
            index = i
    nxt = AFFINITY_LEVELS[index + 1][0] if index + 1 < len(AFFINITY_LEVELS) else None
    return index, AFFINITY_LEVELS[index][1], AFFINITY_LEVELS[index][0], nxt

# (id, symbol, condition) - names/descriptions are i18n keys "ach_<id>"
ACHIEVEMENTS = [
    ("first_pom", "\u2605", lambda s: s["total_poms"] >= 1),
    ("poms_10", "\u2726", lambda s: s["total_poms"] >= 10),
    ("poms_50", "\u2742", lambda s: s["total_poms"] >= 50),
    ("poms_100", "\u2654", lambda s: s["total_poms"] >= 100),
    ("poms_250", "\u265b", lambda s: s["total_poms"] >= 250),
    ("day_4", "\u2618", lambda s: s["best_day_poms"] >= 4),
    ("day_8", "\u2600", lambda s: s["best_day_poms"] >= 8),
    ("streak_3", "\u2668", lambda s: s["best_streak"] >= 3),
    ("streak_7", "\u2604", lambda s: s["best_streak"] >= 7),
    ("streak_14", "\u269d", lambda s: s["best_streak"] >= 14),
    ("early_bird", "\u263c", lambda s: s["early_bird"]),
    ("night_owl", "\u263e", lambda s: s["night_owl"]),
    ("weekend", "\u2740", lambda s: s["weekend"]),
    ("level_5", "\u2691", lambda s: s["level"] >= 5),
    ("level_10", "\u269c", lambda s: s["level"] >= 10),
    ("pet_lover", "\u2665", lambda s: s["pets_total"] >= 50),
    ("tickler", "\u266a", lambda s: s["tickles_total"] >= 100),
    ("chef", "\u2615", lambda s: s["snacks_total"] >= 20),
    ("friend_1", "\u263a", lambda s: s["friends"] >= 1),
    ("team_1", "\u2691", lambda s: s["groups"] >= 1),
    ("close_friend", "\u2766", lambda s: s.get("max_affinity", 0) >= 150),
    ("visitor", "\u2302", lambda s: s.get("visits_sent", 0) >= 1),
]
ACH_IDS = [a[0] for a in ACHIEVEMENTS]
ACH_SYMBOL = {a[0]: a[1] for a in ACHIEVEMENTS}


# =============================================================================
# Levels & stats (offline)
# =============================================================================

def xp_for_level(level: int) -> int:
    """Total XP needed to reach `level` (level 1 = 0 XP, 2 = 100, 3 = 300, 4 = 600...)."""
    return 50 * level * (level - 1)


def level_for_xp(xp: int) -> int:
    return max(1, int((1 + math.sqrt(1 + max(0, xp) / 12.5)) / 2))


def week_key(day: date) -> str:
    year, week, _ = day.isocalendar()
    return f"{year}-W{week:02d}"


def _parse(ts):
    try:
        return datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def compute_stats(db_path, pet_state: dict | None = None, friends: int = 0, groups: int = 0,
                  today: date | None = None, max_affinity: int = 0, visits_sent: int = 0) -> dict:
    """Everything the level / achievement / Friends features need, from local data only."""
    today = today or date.today()
    pet_state = pet_state or {}
    per_day: dict[str, int] = {}
    minutes_day: dict[str, int] = {}
    early = night = weekend = False
    try:
        con = sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True, timeout=2)
        try:
            rows = con.execute(
                "SELECT day, started_at, ended_at FROM sessions WHERE kind = 'work' AND completed = 1"
            ).fetchall()
        finally:
            con.close()
    except sqlite3.Error as exc:
        logger.debug("stats: no session data (%s)", exc)
        rows = []
    for day, started, ended in rows:
        day = str(day)
        per_day[day] = per_day.get(day, 0) + 1
        start_dt = _parse(started)
        end_dt = _parse(ended)
        minutes = 25
        if start_dt and end_dt:
            minutes = max(0, min(90, int((end_dt - start_dt).total_seconds() // 60)))
        minutes_day[day] = minutes_day.get(day, 0) + minutes
        stamp = end_dt or start_dt
        if stamp:
            if stamp.hour < 8:
                early = True
            if stamp.hour >= 22:
                night = True
            if stamp.weekday() >= 5:
                weekend = True

    total = sum(per_day.values())
    active_days = sorted(d for d, n in per_day.items() if n > 0)
    xp = 20 * total + 10 * len(active_days)
    level = level_for_xp(xp)

    # current streak: consecutive active days ending today (or yesterday if today is still empty)
    streak = 0
    cursor = today if per_day.get(today.isoformat()) else today - timedelta(days=1)
    while per_day.get(cursor.isoformat()):
        streak += 1
        cursor -= timedelta(days=1)
    best = run = 0
    previous = None
    for d in active_days:
        current = date.fromisoformat(d)
        run = run + 1 if previous and (current - previous).days == 1 else 1
        best = max(best, run)
        previous = current

    week = week_key(today)
    week_poms = week_minutes = 0
    for d, n in per_day.items():
        try:
            if week_key(date.fromisoformat(d)) == week:
                week_poms += n
                week_minutes += minutes_day.get(d, 0)
        except ValueError:
            continue
    stats = {
        "total_poms": total,
        "xp": xp,
        "level": level,
        "level_floor": xp_for_level(level),
        "level_next": xp_for_level(level + 1),
        "streak": streak,
        "best_streak": max(best, streak),
        "best_day_poms": max(per_day.values(), default=0),
        "day": today.isoformat(),
        "today_poms": per_day.get(today.isoformat(), 0),
        "today_minutes": minutes_day.get(today.isoformat(), 0),
        "week": week,
        "week_poms": week_poms,
        "week_minutes": week_minutes,
        "early_bird": early,
        "night_owl": night,
        "weekend": weekend,
        "pets_total": int(pet_state.get("pets_total", 0) or 0),
        "tickles_total": int(pet_state.get("tickles_total", 0) or 0),
        "snacks_total": int(pet_state.get("snacks_total", 0) or 0),
        "friends": friends,
        "groups": groups,
        "max_affinity": max_affinity,
        "visits_sent": visits_sent,
    }
    stats["achievements"] = [aid for aid, _sym, cond in ACHIEVEMENTS if cond(stats)]
    return stats


# =============================================================================
# Server client
# =============================================================================

class ApiError(Exception):
    def __init__(self, code: str, status: int = 0):
        super().__init__(code)
        self.code = code
        self.status = status


def api_call(method: str, path: str, body=None, account: dict | None = None, timeout=15) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(API_URL + path, data=data, method=method)
    req.add_header("content-type", "application/json")
    req.add_header("user-agent", "Pips")
    if account:
        req.add_header("authorization", f"Bearer {account['id']}.{account['secret']}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as err:
        try:
            payload = json.loads(err.read().decode("utf-8"))
        except Exception:
            payload = {}
        raise ApiError(payload.get("error", "http_%d" % err.code), err.code) from None
    except (urllib.error.URLError, OSError, ValueError) as err:
        raise ApiError("offline") from err


def default_display_name() -> str:
    raw = os.environ.get("USERNAME", "") or "Friend"
    first = raw.replace(".", "_").split("_")[0]
    return (first[:1].upper() + first[1:])[:24] or "Friend"


# =============================================================================
# Social controller (lives inside the DesktopPet)
# =============================================================================

class Social:
    def __init__(self, pet):
        self.pet = pet
        self.path = Path(pet.base_dir) / "data" / "social.json"
        self.db_path = Path(pet.base_dir) / "data" / "productivity.db"
        self.data = self._load()
        self.results: queue.Queue = queue.Queue()
        self.window = None
        self.board = None
        self.board_at = 0.0
        self.stats = None
        self.busy = False
        self.rooms: dict[str, list] = {}        # "dm:CODE" / "c:ID" -> messages (oldest first)
        self.invites: list = []
        self.history_loaded = False
        self.chat_open_room = None              # room shown in the chat view (fast polling)
        self.visitors = []
        now = time.monotonic()
        self._next_ach = now + 20
        self._next_sync = now + 45
        self._next_board = now + 90
        self._next_inbox = now + 8
        self._inbox_busy = False
        self._last_news = 0.0

    # ---- persistence ----
    def _load(self) -> dict:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
            tmp.replace(self.path)
        except OSError as exc:
            logger.warning("social: could not save %s: %s", self.path, exc)

    @property
    def enabled(self) -> bool:
        return bool(self.pet.s.get("friends", False)) and bool(self.data.get("id"))

    @property
    def account(self):
        if self.data.get("id") and self.data.get("secret"):
            return {"id": self.data["id"], "secret": self.data["secret"]}
        return None

    # ---- lookups ----
    def friends(self) -> list:
        return list((self.board or {}).get("friends", []))

    def friend(self, code: str):
        for f in self.friends():
            if f.get("code") == code:
                return f
        return None

    def circles(self) -> list:
        return list((self.board or {}).get("circles", []))

    def circle(self, circle_id: str):
        for c in self.circles():
            if c.get("id") == circle_id:
                return c
        return None

    def room_title(self, room: str) -> str:
        if room.startswith("dm:"):
            f = self.friend(room[3:])
            return f["name"] if f else room[3:]
        c = self.circle(room[2:])
        return c["name"] if c else "?"

    def unread(self, room: str) -> int:
        read = self.data.get("read", {}).get(room, 0)
        return sum(1 for m in self.rooms.get(room, []) if not m.get("mine") and m["id"] > read)

    def total_unread(self) -> int:
        return sum(self.unread(r) for r in self.rooms)

    def mark_read(self, room: str):
        msgs = self.rooms.get(room) or []
        if msgs:
            self.data.setdefault("read", {})[room] = msgs[-1]["id"]
            self.save()

    # ---- coins ----
    def affinity_levels(self) -> int:
        return sum(affinity_level(f.get("affinity", 0))[0] for f in self.friends())

    def wallet(self) -> dict:
        shop = getattr(self.pet, "shop", None)
        if not shop:
            return {"balance": 0, "total": 0, "spent": 0}
        stats = self.stats or self.refresh_stats()
        return shop.wallet(stats, len(self.data.get("unlocked", {})), self.affinity_levels())

    def my_look(self) -> dict:
        shop = getattr(self.pet, "shop", None)
        if not shop:
            return {}
        look = dict(shop.equipped())
        look["moves"] = shop.moves()
        return look

    # ---- stats / achievements ----
    def refresh_stats(self) -> dict:
        board = self.board or {}
        self.stats = compute_stats(
            self.db_path, self.pet.st,
            friends=len(board.get("friends", [])) if self.enabled else 0,
            groups=(len(self.data.get("groups", [])) + len(board.get("circles", []))) if self.enabled else 0,
            max_affinity=max([f.get("affinity", 0) for f in board.get("friends", [])] or [0]) if self.enabled else 0,
            visits_sent=int(self.data.get("visits_sent", 0)))
        return self.stats

    def check_achievements(self, announce=True) -> list:
        stats = self.refresh_stats()
        unlocked = self.data.setdefault("unlocked", {})
        first_run = not unlocked and not self.data.get("ach_seeded")
        new = [aid for aid in stats["achievements"] if aid not in unlocked]
        if new:
            stamp = date.today().isoformat()
            for aid in new:
                unlocked[aid] = stamp
            self.data["ach_seeded"] = True
            self.save()
            if announce and not first_run:
                aid = new[-1]
                more = len(new) - 1
                text = t("ach_unlocked", name=t("ach_" + aid).split(":")[0])
                if more:
                    text += t("ach_more", n=more)
                if pet_shop is not None:
                    text += t("shop_coins_plus", n=pet_shop.COINS_PER_ACHIEVEMENT * len(new))
                self.pet.set_action("love", 2.0)
                self.pet._spawn("sparkle", 5)
                self.pet._voice("happy")
                self.pet.say(text, duration=6, priority=2, on_click=self.open_window)
        elif not self.data.get("ach_seeded"):
            self.data["ach_seeded"] = True
            self.save()
        self._refresh_window()
        return new

    # ---- background work ----
    def _run(self, kind, fn, *args):
        def worker():
            try:
                result = fn(*args)
                self.results.put((kind, True, result))
            except ApiError as err:
                self.results.put((kind, False, err.code))
            except Exception as exc:  # pragma: no cover - defensive
                logger.exception("social worker failed")
                self.results.put((kind, False, str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _profile_payload(self) -> dict:
        stats = self.stats or self.refresh_stats()
        unlocked = list(self.data.get("unlocked", {}).keys())
        return {
            "name": self.data.get("name") or default_display_name(),
            "species": self.pet.s.get("species", "cat"),
            "color": self.pet.s.get("color", "#ffc78f"),
            "level": stats["level"],
            "xp": stats["xp"],
            "streak": stats["streak"],
            "day": stats["day"],
            "today_poms": stats["today_poms"],
            "today_minutes": stats["today_minutes"],
            "week": stats["week"],
            "week_poms": stats["week_poms"],
            "week_minutes": stats["week_minutes"],
            "achievements": unlocked,
            "mood": self.pet.mood(),
            "look": self.my_look(),
        }

    def _board_now(self, account=None):
        stats = self.stats or self.refresh_stats()
        return api_call("GET", f"/v1/board?day={stats['day']}&week={stats['week']}", None,
                        account or self.account)

    def _sync_and_board(self, payload, account):
        api_call("POST", "/v1/profile", payload, account)
        return self._board_now(account)

    def sync(self):
        if not self.enabled:
            return
        self.refresh_stats()
        self._run("board", self._sync_and_board, self._profile_payload(), self.account)

    def enable(self, name: str):
        name = (name or "").strip()[:24] or default_display_name()
        self.data["name"] = name
        self.save()
        self.pet.update_setting("friends", True)
        if self.data.get("id"):
            self.sync()
            return
        self.refresh_stats()
        body = {"name": name, "species": self.pet.s.get("species", "cat"),
                "color": self.pet.s.get("color", "#ffc78f")}
        self.busy = True
        self._run("register", self._register_then_sync, body)

    def _register_then_sync(self, body):
        account = api_call("POST", "/v1/register", body)
        self.results.put(("account", True, account))
        acc = {"id": account["id"], "secret": account["secret"]}
        api_call("POST", "/v1/profile", dict(self._profile_payload()), acc)
        return self._board_now(acc)

    def disable_and_delete(self):
        account = self.account
        self.pet.update_setting("friends", False)
        self.board = None
        self.rooms = {}
        self.invites = []
        self.history_loaded = False
        if account:
            self._run("deleted", api_call, "DELETE", "/v1/me", None, account)
        for key in ("id", "secret", "code", "groups", "read", "seen_id", "notified_invites"):
            self.data.pop(key, None)
        self.save()
        self._refresh_window()

    def _then_board(self, method, path, body):
        result = api_call(method, path, body, self.account)
        board = self._board_now()
        board["_result"] = result
        return board

    def _act(self, kind, path, body):
        if self.enabled:
            self._run(kind, self._then_board, "POST", path, body)

    def add_friend(self, code: str):
        self._act("friend_added", "/v1/friends/add", {"code": code.strip().upper()})

    def remove_friend(self, code: str):
        self._act("friend_removed", "/v1/friends/remove", {"code": code})

    def join_group(self, group: str):
        self._act("group_joined", "/v1/groups/join", {"group": group})

    def leave_group(self, group: str):
        self._act("group_left", "/v1/groups/leave", {"group": group})

    def create_circle(self, name: str):
        self._act("circle_created", "/v1/circles/create", {"name": name})

    def invite_to_circle(self, circle_id: str, code: str):
        self._act("circle_invited", "/v1/circles/invite", {"circle": circle_id, "code": code})

    def respond_invite(self, circle_id: str, accept: bool):
        self.invites = [i for i in self.invites if i.get("circle") != circle_id]
        self._act("circle_joined" if accept else "circle_declined", "/v1/circles/respond",
                  {"circle": circle_id, "accept": bool(accept)})

    def leave_circle(self, circle_id: str):
        self._act("circle_left", "/v1/circles/leave", {"circle": circle_id})

    def kick_from_circle(self, circle_id: str, code: str):
        self._act("circle_kicked", "/v1/circles/kick", {"circle": circle_id, "code": code})

    # ---- chat & interactions ----
    def send(self, room: str, kind: str = "text", body: str = ""):
        if not self.enabled:
            return
        shop = getattr(self.pet, "shop", None)
        if kind == "visit" and shop and shop.moves() and not body:
            body = random.choice(shop.moves())       # my pet shows off a move when it arrives
        if shop:
            shop.add_interaction_bonus()
        payload = {"kind": kind, "body": body[:500]}
        if room.startswith("dm:"):
            payload["to"] = room[3:]
        else:
            payload["circle"] = room[2:]
        if kind == "visit":
            self.data["visits_sent"] = int(self.data.get("visits_sent", 0)) + 1
            self.save()
        self._run("sent", self._send_then_inbox, payload, room, kind)

    def _send_then_inbox(self, payload, room, kind):
        api_call("POST", "/v1/send", payload, self.account)
        result = api_call("GET", f"/v1/inbox?since={self._since()}", None, self.account)
        result["_room"] = room
        result["_kind"] = kind
        return result

    def _since(self) -> int:
        return max([m["id"] for msgs in self.rooms.values() for m in msgs] or [0]) if self.history_loaded else 0

    def poll_inbox(self):
        if not self.enabled or self._inbox_busy:
            return
        self._inbox_busy = True
        self._run("inbox", api_call, "GET", f"/v1/inbox?since={self._since()}", None, self.account)

    def _take_inbox(self, result, initial=False):
        seen = int(self.data.get("seen_id", 0))
        fresh = []
        for m in result.get("messages", []):
            room = m.get("room")
            if not room:
                continue
            msgs = self.rooms.setdefault(room, [])
            if msgs and msgs[-1]["id"] >= m["id"]:
                continue
            msgs.append(m)
            if len(msgs) > MAX_ROOM_HISTORY:
                del msgs[: len(msgs) - MAX_ROOM_HISTORY]
            if m["id"] > seen and not m.get("mine"):
                fresh.append(m)
        top = max([m["id"] for m in result.get("messages", [])] or [seen])
        if top > seen:
            self.data["seen_id"] = top
            self.save()
        if self.chat_open_room:
            self.mark_read(self.chat_open_room)
        self.invites = result.get("invites", self.invites)
        self._notify_invites()
        # first load after start: only react to things that arrived very recently
        cutoff = time.time() - (10 * 60 if initial else 24 * 3600)
        for m in fresh[-5:]:
            if m.get("at", 0) >= cutoff:
                self._react_to(m)

    def _notify_invites(self):
        notified = set(self.data.get("notified_invites", []))
        for inv in self.invites:
            if inv["circle"] not in notified:
                notified.add(inv["circle"])
                self.pet.say(t("cir_invited_you", name=inv.get("by", "?"), group=inv.get("name", "?")),
                             duration=7, priority=1, on_click=lambda: self.open_window("groups"))
        self.data["notified_invites"] = sorted(notified)[-50:]
        self.save()

    def _quiet(self) -> bool:
        return bool(self.pet.focus and self.pet.s.get("quiet_focus", True))

    def _react_to(self, m):
        """Your pet reacts to an incoming message / interaction."""
        pet = self.pet
        who = (m.get("from") or {}).get("name", "?")
        kind = m.get("kind", "text")
        room = m.get("room", "")
        open_chat = lambda r=room: self.open_window("chat", room=r)
        if self.window and self.window.alive() and self.chat_open_room == room and kind == "text":
            return  # you're looking at it already
        pet_name = pet.s.get("name", "Pip")
        if kind == "text":
            body = m.get("body", "")
            body = body if len(body) <= 80 else body[:77] + "\u2026"
            where = "" if room.startswith("dm:") else " (" + self.room_title(room) + ")"
            pet.say(t("chat_bubble", name=who + where, text=body), duration=7,
                    priority=0 if self._quiet() else 1, on_click=open_chat)
            if not self._quiet():
                pet.set_action("hop", 0.55)
                pet._voice("greet")
            return
        if kind == "wave":
            pet.set_action("hop", 0.55)
            pet._voice("greet")
        elif kind == "pet":
            pet.set_action("petted", 1.8)
            pet._spawn("heart", 3)
            pet._bump("happiness", 3)
            pet._voice("pet")
        elif kind == "snack":
            pet.set_action("eat", 2.0)
            pet._spawn("crumb", 4)
            pet._bump("fullness", 10)
            pet._bump("happiness", 4)
            pet._voice("eat")
        elif kind in ("highfive", "cheer"):
            pet.set_action("cheer", 1.4)
            pet._spawn("sparkle", 4)
            pet._voice("happy")
        elif kind == "visit":
            who_info = dict(m.get("from") or {})
            if m.get("body"):
                who_info["trick"] = m["body"]
            self.start_visit(who_info)
            pet._voice("greet")
        group = "" if room.startswith("dm:") else self.room_title(room)
        pet.say(t("ix_in_" + kind, name=who, pet=pet_name, group=group), duration=6, priority=1, on_click=open_chat)

    def start_visit(self, who: dict):
        if len(self.visitors) >= 2 or not self.pet.visible or self.pet.fs_hidden:
            return
        try:
            self.visitors.append(VisitorPet(self, who))
        except Exception:
            logger.exception("visit failed")

    # ---- main-thread pump ----
    def poll(self):
        while True:
            try:
                kind, ok, payload = self.results.get_nowait()
            except queue.Empty:
                break
            try:
                self._handle(kind, ok, payload)
            except Exception:
                logger.exception("social: handling %s failed", kind)

    def _handle(self, kind, ok, payload):
        if kind == "account":
            if ok:
                self.data.update({"id": payload["id"], "secret": payload["secret"], "code": payload["code"]})
                self.save()
            return
        if kind == "register":
            self.busy = False
        if kind == "inbox":
            self._inbox_busy = False
        if not ok:
            if payload == "unauthorized" and kind != "deleted":
                logger.warning("social: account no longer valid - turning Friends off")
                for key in ("id", "secret", "code", "groups"):
                    self.data.pop(key, None)
                self.save()
                self.pet.update_setting("friends", False)
            if kind != "inbox" and self.window and self.window.alive():
                self.window.show_error(payload)
            return
        if not self.enabled:
            return  # late reply after Friends was turned off
        if kind == "inbox" or (kind == "sent" and isinstance(payload, dict)):
            initial = not self.history_loaded
            self.history_loaded = True
            self._take_inbox(payload, initial=initial)
            if kind == "sent":
                pet = self.pet
                pet.set_action("hop", 0.55)
                if payload.get("_kind") in INTERACTIONS:
                    pet.say(t("ix_sent_" + payload["_kind"], name=self.room_title(payload["_room"])),
                            duration=3, priority=1)
                    if payload["_kind"] == "visit":
                        self.check_achievements()
        if isinstance(payload, dict) and "friends" in payload:
            self._take_board(payload)
        if kind == "friend_added":
            friend = payload.get("_result", {}).get("friend", {})
            self.pet.set_action("cheer", 1.4)
            self.pet._voice("greet")
            self.pet.say(t("fr_added", name=friend.get("name", "?")), duration=4, priority=1)
            self.check_achievements()
        elif kind in ("group_joined", "circle_joined", "circle_created"):
            self.check_achievements()
        elif kind == "circle_invited":
            self.pet.say(t("cir_invite_sent", name=payload.get("_result", {}).get("invited", "?")),
                         duration=3, priority=1)
        self._refresh_window()

    def _take_board(self, board):
        if not self.enabled:
            return
        old = {f["code"]: f for f in (self.board or {}).get("friends", [])}
        self.board = board
        self.board_at = time.time()
        self.data["code"] = board.get("me", {}).get("code", self.data.get("code"))
        self.data["groups"] = [g["code"] for g in board.get("groups", [])]
        self.invites = board.get("invites", self.invites)
        self.save()
        self._notify_invites()
        if old and self.pet.s.get("chatty", True) and time.monotonic() - self._last_news > FRIEND_NEWS_GAP_S:
            for friend in board.get("friends", []):
                before = old.get(friend["code"])
                if before and friend["today_poms"] > before["today_poms"]:
                    self._last_news = time.monotonic()
                    self.pet.say(t("fr_news", name=friend["name"], n=friend["today_poms"]),
                                 duration=5, priority=0, on_click=self.open_window)
                    break
                if before and affinity_level(friend.get("affinity", 0))[0] > affinity_level(before.get("affinity", 0))[0]:
                    self._last_news = time.monotonic()
                    self.pet.set_action("love", 2.0)
                    self.pet.say(t("aff_level_up", name=friend["name"],
                                   level=t(affinity_level(friend["affinity"])[1])),
                                 duration=6, priority=1, on_click=self.open_window)
                    break

    def _refresh_window(self):
        if self.window and self.window.alive():
            self.window.refresh()

    def tick(self, now: float):
        self.poll()
        self.visitors = [v for v in self.visitors if v.alive]
        if now >= self._next_ach:
            self._next_ach = now + ACH_CHECK_EVERY_S
            try:
                self.check_achievements()
            except Exception:
                logger.exception("achievement check failed")
        if not self.enabled:
            return
        if now >= self._next_sync:
            self._next_sync = now + SYNC_EVERY_S
            self._next_board = now + BOARD_EVERY_S
            self.sync()
        elif now >= self._next_board:
            self._next_board = now + BOARD_EVERY_S
            self.sync()
        fast = self.window and self.window.alive() and self.chat_open_room
        if now >= self._next_inbox:
            self._next_inbox = now + (INBOX_FAST_S if fast else INBOX_EVERY_S)
            self.poll_inbox()

    def on_pomodoro(self):
        try:
            self.check_achievements()
        except Exception:
            logger.exception("achievement check failed")
        if self.enabled:
            self._next_sync = time.monotonic() + SYNC_EVERY_S
            self.sync()

    # ---- window ----
    def open_window(self, tab=None, room=None):
        import social_ui
        if self.window and self.window.alive():
            self.window.win.deiconify()
            self.window.win.lift()
        else:
            self.window = social_ui.FriendsWindow(self)
        if tab:
            self.window.show_tab(tab, room=room)
        else:
            self.window.refresh()
        if self.enabled and time.time() - self.board_at > 30:
            self.sync()
        if self.enabled:
            self.poll_inbox()

    def close(self):
        if self.window and self.window.alive():
            self.window.close()
        for v in self.visitors:
            v.leave(now=True)


# =============================================================================
# A friend's pet visiting your desktop
# =============================================================================

class VisitorPet:
    DURATION_S = 25.0

    def __init__(self, social: Social, who: dict):
        import pet as pet_mod  # late import: pet imports social

        self.pet_mod = pet_mod
        self.social = social
        self.host = social.pet
        self.who = who
        self.alive = True
        host = self.host
        self.size = int(host.size * 0.9)
        self.W = int(self.size * 2.0)
        self.H = int(self.size * 2.0)
        species = who.get("species") if who.get("species") in pet_mod.SPECIES else "cat"
        self.props = pet_shop.clean_look(who.get("look")) if pet_shop is not None else {}
        self.trick = who.get("trick") if pet_shop is not None and who.get("trick") in pet_shop.MOVES else None
        self.trick_t0 = None
        self.look_base = pet_mod.default_look({"species": species,
                                               "color": who.get("color") or pet_mod.SPECIES[species]["color"]})
        self.win = tk.Toplevel(host.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.configure(bg=pet_mod.KEY)
        try:
            self.win.attributes("-transparentcolor", pet_mod.KEY)
        except tk.TclError:
            pass
        self.cv = tk.Canvas(self.win, width=self.W, height=self.H, bg=pet_mod.KEY, highlightthickness=0,
                            cursor="hand2")
        self.cv.pack()
        self.cv.bind("<Button-1>", self._on_click)
        wx, wy, w, h = host.window_rect()
        screen_w = host.root.winfo_screenwidth()
        self.side = -1 if wx + w + self.W > screen_w - 10 else 1   # which side of your pet
        self.floor = wy + h
        self.target_x = (wx - self.W + 10) if self.side < 0 else (wx + w - 10)
        self.x = float(self.target_x + self.side * 160)
        self.t0 = time.monotonic()
        self.hop_until = self.t0 + 1.5
        self.hearts = []
        self.leaving = False
        self._frame()

    def _on_click(self, _event):
        self.hop_until = time.monotonic() + 0.8
        self.hearts.append([self.W / 2, self.H - self.size * 1.1, time.monotonic()])

    def leave(self, now=False):
        if now:
            self.alive = False
            try:
                self.win.destroy()
            except tk.TclError:
                pass
        else:
            self.leaving = True

    def _frame(self):
        if not self.alive:
            return
        now = time.monotonic()
        age = now - self.t0
        if age > self.DURATION_S:
            self.leaving = True
        goal = self.target_x + (self.side * 220 if self.leaving else 0)
        walking = abs(goal - self.x) > 2
        if walking:
            step = 3.2 if self.leaving else 2.6
            self.x += step if goal > self.x else -step
        elif self.leaving:
            self.leave(now=True)
            return
        look = dict(self.look_base)
        look["t"] = now
        look["facing"] = (1 if goal > self.x else -1) if walking else -self.side
        phase = now * 9
        if walking:
            look["foot_l"] = math.sin(phase) * 3
            look["foot_r"] = -math.sin(phase) * 3
            look["hop"] = abs(math.sin(phase)) * 2
        if now < self.hop_until:
            look["hop"] = abs(math.sin((self.hop_until - now) * 9)) * 10
            look["mouth"] = "open"
        else:
            look["mouth"] = "smile"
        if int(age * 2) % 9 == 0 and not walking:
            look["eyes"] = "happy"
        if self.look_base["species"] in self.pet_mod.SPECIES and \
                self.pet_mod.SPECIES[self.look_base["species"]].get("cat") == "air":
            look["flap"] = math.sin(now * 14)
            look["hover"] = 6 + math.sin(now * 2) * 3
        if self.trick and not walking and not self.leaving and age > 2.5:
            if self.trick_t0 is None:
                self.trick_t0 = now
            span = min(pet_shop.MOVES[self.trick][1], 4.0)
            p = (now - self.trick_t0) / span
            if p <= 1.0 and self.trick not in ("spider", "moonwalk"):
                pet_shop.trick_pose(look, self.trick, p, now)
            elif p <= 1.0:
                pet_shop.trick_pose(look, "dance", p, now)
        if not walking and age > 3 and int(age) % 5 == 0 and not self.hearts:
            self.hearts.append([self.W / 2 + random.uniform(-8, 8), self.H - self.size * 1.1, now])
        try:
            self.cv.delete("all")
            if self.props:
                pet_shop.draw_back_props(self.cv, self.pet_mod.body_geometry(self.W / 2, self.H - 4, self.size, look),
                                         self.props, now)
            geo = self.pet_mod.draw_pet(self.cv, self.W / 2, self.H - 4, self.size, look)
            if self.props:
                pet_shop.draw_front_props(self.cv, geo, self.props, now)
            name = (self.who.get("name") or "?")[:16]
            label_y = self.H - self.size * 1.25 - look.get("hop", 0) - look.get("hover", 0)
            self.cv.create_text(self.W / 2, max(8, label_y), text=name, font=("Segoe UI", 8, "bold"),
                                fill="#8b1a1a")
            keep = []
            for hx, hy, born in self.hearts:
                life = now - born
                if life < 1.6:
                    self.cv.create_text(hx, hy - life * 25, text="\u2665", fill="#ff6b8b",
                                        font=("Segoe UI Symbol", 12))
                    keep.append([hx, hy, born])
            self.hearts = keep
            self.win.geometry("%dx%d+%d+%d" % (self.W, self.H, int(self.x), int(self.floor - self.H)))
        except tk.TclError:
            self.alive = False
            return
        self.host.root.after(40, self._frame)

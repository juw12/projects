"""Original synthetic CADScore benchmark. Run with --test for regressions or --report for results."""
import argparse
import csv
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from .score import Mesh, check, read_stl, score
from .verify import write_stl


SEGMENTS = 32


def perimeter(width, height, cx, cy, n):
    corners = np.array([[-width, -height], [width, -height], [width, height], [-width, height]]) / 2
    return np.array([
        [cx, cy] + corners[k] + (corners[(k + 1) % 4] - corners[k]) * (i / (n // 4))
        for k in range(4) for i in range(n // 4)
    ])


def triangulate_plate(tile_width, tile_height, height, features):
    """Tile a plate along X. Each tile can contain one open-top pocket. No internal seam faces."""
    triangles = []
    n = SEGMENTS

    def vertex(p, z):
        return (float(p[0]), float(p[1]), float(z))

    def quad(a, b, c, d):
        triangles.extend([(a, b, c), (a, c, d)])

    def cap(ring, z, upward):
        centre = vertex(np.mean(ring, axis=0), z)
        for i, point in enumerate(ring):
            a = vertex(point, z)
            b = vertex(ring[(i + 1) % n], z)
            triangles.append((a, b, centre) if upward else (b, a, centre))

    def annulus(outer, inner, z, upward):
        for i in range(n):
            j = (i + 1) % n
            face = [vertex(outer[i], z), vertex(outer[j], z), vertex(inner[j], z), vertex(inner[i], z)]
            quad(*(face if upward else face[::-1]))

    for col, feature in enumerate(features):
        outer = perimeter(tile_width, tile_height, tile_width * (col + 0.5), tile_height / 2, n)
        for i in range(n):
            edge = i // (n // 4)
            if (edge == 1 and col < len(features) - 1) or (edge == 3 and col > 0):
                continue
            j = (i + 1) % n
            quad(vertex(outer[i], 0), vertex(outer[j], 0), vertex(outer[j], height), vertex(outer[i], height))
        if feature is None:
            cap(outer, 0, False)
            cap(outer, height, True)
            continue
        cx, cy = feature['center']
        floor = feature.get('floor', 0)
        if 'size' in feature:
            inner = perimeter(*feature['size'], cx, cy, n)
        else:
            theta = np.arange(n) * (2 * np.pi / n) - 3 * np.pi / 4
            radius = feature['radius'] * (1 + feature.get('lobe', 0) * np.sin(4 * theta))
            inner = np.column_stack([cx + radius * np.cos(theta), cy + radius * np.sin(theta)])
        annulus(outer, inner, height, True)
        if floor > 0:
            cap(outer, 0, False)
            cap(inner, floor, True)
        else:
            annulus(outer, inner, 0, False)
        for i in range(n):
            j = (i + 1) % n
            quad(vertex(inner[i], height), vertex(inner[j], height), vertex(inner[j], floor), vertex(inner[i], floor))
    return np.array(triangles)


def requirements(case, prompt, width, depth, height, volume, volume_tolerance):
    rules = [
        {'kind': 'extent_mm', 'axis': axis, 'target': value, 'tolerance': 0.05}
        for axis, value in zip('xyz', (width, depth, height))
    ]
    rules.append({'kind': 'volume_mm3', 'target': volume, 'tolerance': volume_tolerance})
    return {'id': case, 'prompt': prompt, 'units': 'mm', 'requirements': rules}


def ray(axis, through, intervals):
    return {'kind': 'ray_intervals_mm', 'axis': axis, 'through_mm': through, 'target': intervals, 'tolerance': 0.05}


def bore_profile(x, y, radius):
    return {
        'kind': 'bore_profile_mm', 'centre_xy_mm': [x, y], 'z_mm': [1.37, 2.21],
        'target': radius, 'tolerance': 0.05, 'directions': 32,
    }


def benchmark_cases():
    pocket = {'center': (10, 8), 'size': (6, 4), 'floor': 2}
    pocket_spec = requirements('blind-pocket', '20 by 16 by 5 mm plate; centre a 6 by 4 mm rectangular pocket, 3 mm deep from the top. Linear tolerance 0.05 mm.', 20, 16, 5, 20 * 16 * 5 - 6 * 4 * 3, 0.5)
    pocket_spec['requirements'].extend([
        ray('z', [10.17, 8.11, 0], [[0, 2]]),
        ray('x', [0, 8.12, 3.33], [[0, 7], [13, 20]]),
        ray('y', [9.73, 0, 3.33], [[0, 6], [10, 16]]),
    ])
    bore = {'center': (10, 8), 'radius': 3}
    bore_spec = requirements('circular-bore', '20 by 16 by 4 mm plate; a centred 6 mm diameter circular through bore. Bore centre and radial profile within 0.05 mm of nominal.', 20, 16, 4, 20 * 16 * 4 - math.pi * 9 * 4, 1.5)
    bore_spec['requirements'].extend([
        ray('x', [0, 8, 1.37], [[0, 7], [13, 20]]),
        ray('y', [10, 0, 2.21], [[0, 5], [11, 16]]),
        ray('z', [10.11, 8.17, 0], []),
        bore_profile(10, 8, 3),
    ])
    centres = [6, 18, 30]
    pattern = [{'center': (x, 6), 'radius': 1.5} for x in centres]
    pattern_spec = requirements('hole-pattern', '36 by 12 by 4 mm plate; three circular through bores of radius 1.5 mm at X = 6, 18, 30 mm, all at Y = 6 mm. Each radial profile must be within 0.05 mm of nominal.', 36, 12, 4, 36 * 12 * 4 - 3 * math.pi * 1.5 ** 2 * 4, 1.5)
    pattern_spec['requirements'].append(ray('x', [0, 6, 1.37], [[0, 4.5], [7.5, 16.5], [19.5, 28.5], [31.5, 36]]))
    for x in centres:
        pattern_spec['requirements'].append(ray('y', [x, 0, 2.21], [[0, 4.5], [7.5, 12]]))
        pattern_spec['requirements'].append(bore_profile(x, 6, 1.5))
    # Ground truth from the design parameters, not from the scorer. 'within-tolerance'
    # translates the bore +0.03 mm, below the specified 0.05 mm centre/profile tolerance.
    return [
        (pocket_spec, (20, 16, 5), [
            ('nominal', True, [pocket]),
            ('too-shallow', False, [{**pocket, 'floor': 2.6}]),
            ('breakthrough', False, [{**pocket, 'floor': 0}]),
            ('shifted', False, [{**pocket, 'center': (10.4, 8)}]),
        ]),
        (bore_spec, (20, 16, 4), [
            ('nominal', True, [bore]),
            ('within-tolerance', True, [{**bore, 'center': (10.03, 8)}]),
            ('oversize', False, [{**bore, 'radius': 3.3}]),
            ('shifted', False, [{**bore, 'center': (10.15, 8)}]),
            ('omitted', False, [None]),
        ]),
        (pattern_spec, (12, 12, 4), [
            ('nominal', True, pattern),
            ('one-omitted', False, [pattern[0], None, pattern[2]]),
            ('one-shifted', False, [pattern[0], {**pattern[1], 'center': (18.3, 6)}, pattern[2]]),
            ('off-axis-lobes', False, [pattern[0], {**pattern[1], 'lobe': 0.12}, pattern[2]]),
        ]),
    ]


class BenchmarkTests(unittest.TestCase):
    def test_closed_and_volume(self):
        for spec, dims, variants in benchmark_cases():
            for name, _, features in variants:
                area_lost = 0
                for f in features:
                    if f is None:
                        continue
                    if 'size' in f:
                        area = math.prod(f['size'])
                    else:
                        radii = [f['radius'] * (1 + f.get('lobe', 0) * math.sin(4 * k * 2 * math.pi / SEGMENTS - 3 * math.pi)) for k in range(SEGMENTS)]
                        area = math.sin(2 * math.pi / SEGMENTS) * sum(a * b for a, b in zip(radii, radii[1:] + radii[:1])) / 2
                    area_lost += area * (dims[2] - f.get('floor', 0))
                mesh = Mesh(triangulate_plate(*dims, features))
                expected = math.prod(dims) * len(features) - area_lost
                self.assertAlmostEqual(mesh.volume, expected, places=8, msg=spec['id'] + '/' + name)

    def test_spec_results_including_known_gap(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'fixture.stl'
            for spec, dims, variants in benchmark_cases():
                for name, expected, features in variants:
                    with self.subTest(family=spec['id'], name=name):
                        write_stl(path, triangulate_plate(*dims, features))
                        rows = check(Mesh(read_stl(path)), spec['requirements'])
                        axial_pass = all(r['pass'] for r in rows if r['kind'] != 'bore_profile_mm')
                        self.assertEqual(axial_pass, expected or name == 'off-axis-lobes')
                        self.assertEqual(all(r['pass'] for r in rows), expected)
                        if name == 'off-axis-lobes':
                            section = next(r['actual'][0] for r in rows if not r['pass'])
                            self.assertAlmostEqual(section['max_mm'], 1.68, places=5)
                            self.assertAlmostEqual(section['min_mm'], 1.32, places=5)
                        if name == 'shifted':
                            self.assertTrue(next(r['pass'] for r in rows if r['kind'] == 'volume_mm3'))
                            self.assertFalse(all(r['pass'] for r in rows if r['kind'] == 'ray_intervals_mm'))

    def test_bad_intervals(self):
        mesh = Mesh(triangulate_plate(20, 16, 4, [None]))
        for target in ([[2, 1]], [[0, 2], [1, 3]], [0, 2], [[0, float('nan')]]):
            with self.assertRaises(ValueError):
                check(mesh, [ray('x', [0, 8, 1], target)])

    def test_ray_returns_world_coordinates(self):
        mesh = Mesh(triangulate_plate(20, 16, 4, [None]) + [-5, 10, -2])
        for axis, endpoints in zip('xyz', ([-5, 15], [10, 26], [-2, 2])):
            np.testing.assert_allclose(mesh.spans(axis, [1.23, 18.37, 1.61]), [endpoints])


SETTINGS = [(12, 512, 42), (24, 512, 42), (40, 512, 42), (24, 4096, 42), (24, 4096, 71)]


def run_report(output):
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'fixture.stl'
        for spec, dims, variants in benchmark_cases():
            write_stl(path, triangulate_plate(*dims, variants[0][2]))
            ref = Mesh(read_stl(path))
            for name, expected, features in variants:
                write_stl(path, triangulate_plate(*dims, features))
                candidate = Mesh(read_stl(path))
                for grid, samples, seed in SETTINGS:
                    report = score(ref, candidate, spec, grid, samples, seed)
                    rows.append({
                        'family': spec['id'], 'variant': name, 'design_should_pass': expected,
                        'before_radial_check': all(r['pass'] for r in report['requirements'] if r['kind'] != 'bore_profile_mm'),
                        'scored_pass': report['passes_spec'], 'checks_passed': report['checks_passed'],
                        'checks_total': report['checks_total'], 'grid': grid, 'samples': samples, 'seed': seed,
                        'iou': report['similarity']['voxel_iou'],
                        'chamfer_mm': report['similarity']['surface_chamfer_mm'],
                        'failed_rules': json.dumps([r for r in report['requirements'] if not r['pass']], separators=(',', ':')),
                    })
    with output.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    mode = cli.add_mutually_exclusive_group(required=True)
    mode.add_argument('--test', action='store_true')
    mode.add_argument('--report', type=Path, metavar='CSV')
    args = cli.parse_args()
    if args.test:
        unittest.main(argv=['benchmark.py'], verbosity=2)
    else:
        run_report(args.report)

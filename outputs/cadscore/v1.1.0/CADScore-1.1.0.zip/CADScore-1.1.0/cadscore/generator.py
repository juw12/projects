"""Constrained English-to-STL generator. No access to benchmark answers or reference geometry."""
import re

import numpy as np
from manifold3d import Manifold


NUMBER = r'(?:\d+(?:\.\d+)?|\.\d+)'
SEP = r'\s*(?:by|x|×)\s*'
EXAMPLES = {
    'pocket': ['mill a rectangular blind pocket in the top of the plate', 'cut a rectangular recess to the specified depth', 'flat bottom rectangular cavity'],
    'bore': ['a single round through hole in the plate', 'drill one circular bore through the stock', 'one centred cylindrical opening'],
    'pattern': ['a line of equally spaced round through holes', 'drill a row of bores at the given pitch', 'three circular holes at the listed x coordinates'],
}


class SemanticRouter:
    def __init__(self, model_dir):
        import onnxruntime as ort
        from tokenizers import Tokenizer
        self.tok = Tokenizer.from_file(str(model_dir / 'tokenizer.json'))
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        self.net = ort.InferenceSession(str(model_dir / 'model.onnx'), sess_options=options, providers=['CPUExecutionProvider'])
        self.prototypes = {label: [self.embed(s) for s in phrases] for label, phrases in EXAMPLES.items()}

    def embed(self, text):
        enc = self.tok.encode(text)
        ids = np.array([enc.ids[:256]], dtype=np.int64)
        mask = np.array([enc.attention_mask[:256]], dtype=np.int64)
        args = {'input_ids': ids, 'attention_mask': mask, 'token_type_ids': np.zeros_like(ids)}
        outputs = self.net.run(None, {node.name: args[node.name] for node in self.net.get_inputs()})
        features = outputs[0][0]
        vector = features[mask[0] != 0].mean(axis=0)
        return vector / np.linalg.norm(vector)

    def __call__(self, prompt):
        vector = self.embed(prompt)
        return max(self.prototypes, key=lambda label: max(float(vector @ p) for p in self.prototypes[label]))


def rule_router(prompt):
    if re.search(r'\b(pockets?|recess|cavity)\b', prompt):
        return 'pocket'
    if re.search(r'\b(row|pattern|holes|bores|pitch)\b', prompt):
        return 'pattern'
    if re.search(r'\b(hole|bore|opening)\b', prompt):
        return 'bore'
    raise ValueError('Could not identify a supported feature')


def parameter(text, patterns):
    for pattern in patterns:
        hit = re.search(pattern, text)
        if hit:
            return float(hit.group(1))
    raise ValueError('Missing a required feature dimension')


FACE_TOKEN = r'\b(underside|bottom|below|top|above)\b'
AXIS_TOKEN = r'\b(?:along|parallel to|in the direction of)\s+(?:the\s+)?([xyz])(?:[- ]axis)?\b|\b([xyz])[- ]axis\b'


def direction(text, pattern, values, default):
    positive = set()
    negative = set()
    for match in re.finditer(pattern, text):
        token = next(group for group in match.groups() if group is not None)
        before = text[:match.start()]
        negated = re.search(r'\b(?:not|never|rather than|instead of)\s+(?:(?:on|the|from|along|parallel to)\s+)*$', before)
        target = negative if negated else positive
        target.add(values[token])
    if len(positive) > 1 or positive & negative:
        raise ValueError('Conflicting feature directions')
    if positive:
        return next(iter(positive))
    if negative:
        options = set(values.values()) - negative
        if len(options) != 1:
            raise ValueError('Specify the positive feature direction')
        return next(iter(options))
    return default


def select_family(text, router):
    # Explicit manufacturing nouns take precedence over semantic similarity.
    pocket = re.search(r'\b(pocket|recess|cavity)\b', text)
    round_feature = re.search(r'\b(hole|bore|holes|bores)\b', text)
    if pocket and round_feature:
        raise ValueError('Mixed feature families need separate operations')
    if pocket:
        return 'pocket'
    if re.search(r'\b(row|pattern|holes|bores|pitch)\b', text):
        return 'pattern'
    if round_feature:
        return 'bore'
    return router(text)

def generate(prompt, router):
    s = prompt.lower().replace('millimetres', 'mm').replace('millimeters', 'mm')
    if re.search(r'\b(inch|inches|cm)\b', s):
        raise ValueError('Only millimetres are supported')
    stock = re.search(f'({NUMBER}){SEP}({NUMBER}){SEP}({NUMBER})\s*mm', s)
    if not stock:
        raise ValueError('Cannot read stock as width by depth by thickness in mm')
    w, d, h = map(float, stock.groups())
    s = (s[:stock.start()] + ' stock ' + s[stock.end():]).strip()
    if min(w, d, h) <= 0:
        raise ValueError('Invalid stock dimensions')
    if re.search(r'\b(counterbores?|countersinks?|threaded|chamfers?|slots?|diagonal|angled|inclined|tapered|stepped)\b', s):
        raise ValueError('Unsupported feature: refusing to approximate it')
    label = select_family(s, router)
    xy = re.search(rf'\(\s*({NUMBER})\s*,\s*({NUMBER})\s*\)', s)
    if xy:
        cx, cy = map(float, xy.groups())
    elif re.search(r'cent(?:er|re)|middle', s):
        cx, cy = w / 2, d / 2
    else:
        raise ValueError('A feature centre or centred arrangement is required')
    block = Manifold.cube([w, d, h])
    if label == 'pocket':
        rect = re.search(rf'({NUMBER}){SEP}({NUMBER})\s*mm', s)
        if not rect:
            raise ValueError('Missing pocket outline')
        u, v = map(float, rect.groups())
        depth = parameter(s, [rf'({NUMBER})\s*mm\s*deep', rf'depth\s*(?:of|=|:)??\s*({NUMBER})\s*mm'])
        if not 0 < depth < h or min(u, v) <= 0:
            raise ValueError('Invalid blind pocket')
        if re.search(r'\b(?:side|left|right|front|rear|back)\s+(?:face|side)\b', s):
            raise ValueError('Only top and underside pocket entry faces are supported')
        if not (u / 2 < cx < w - u / 2 and v / 2 < cy < d - v / 2):
            raise ValueError('Pocket would break out of stock')
        # "flat bottom" and "pocket floor" describe shape, not an entry face.
        face_text = re.sub(r'\bflat[- ]bottom(?:ed)?\b|\bbottom of (?:the )?pocket\b', '', s)
        face = direction(face_text, FACE_TOKEN, {'above': 'top', 'top': 'top', 'below': 'bottom', 'bottom': 'bottom', 'underside': 'bottom'}, 'top')
        start_z = -1 if face == 'bottom' else h - depth
        cutter = Manifold.cube([u, v, depth + 1]).translate([cx - u / 2, cy - v / 2, start_z])
        block = block - cutter
    else:
        try:
            radius = parameter(s, [rf'(?:radius|r\s*=)\s*({NUMBER})', rf'({NUMBER})\s*mm\s*radius'])
        except ValueError:
            radius = parameter(s, [rf'(?:diameter|diam\.|ø)\s*({NUMBER})', rf'({NUMBER})\s*mm\s*(?:in\s*)?diameter']) / 2
        positions = [(cx, cy)]
        if label == 'pattern':
            match = re.search(r'\b(two|three|four|five|\d+)\s+(?:(?:equally spaced|circular|round|through|drilled)\s+)*(?:holes|bores)', s)
            if not match:
                raise ValueError('Unknown pattern count')
            raw_count = match.group(1)
            count = int(raw_count) if raw_count.isdigit() else ['two', 'three', 'four', 'five'].index(raw_count) + 2
            pitch = parameter(s, [rf'pitch\s*(?:of|=)?\s*({NUMBER})', rf'({NUMBER})\s*mm\s*(?:pitch|apart)'])
            if not 2 <= count <= 128 or pitch <= 0:
                raise ValueError('Invalid pattern')
            if pitch <= 2 * radius:
                raise ValueError('Requested bores overlap or touch')
            axis = direction(s, AXIS_TOKEN, {'x': 'x', 'y': 'y', 'z': 'z'}, 'x')
            if axis == 'z':
                raise ValueError('Through-hole pattern direction must be X or Y')
            shifts = [(k - (count - 1) / 2) * pitch for k in range(count)]
            positions = [(cx + shift, cy) if axis == 'x' else (cx, cy + shift) for shift in shifts]
        for x, y in positions:
            if radius <= 0 or not radius < min(x, w - x, y, d - y):
                raise ValueError('Bore does not fit stock')
            cutter = Manifold.cylinder(h + 2, radius, circular_segments=64).translate([x, y, -1])
            block = block - cutter
    mesh = block.to_mesh()
    if not len(mesh.tri_verts):
        raise ValueError('Empty mesh')
    return label, np.asarray(mesh.vert_properties)[:, :3][np.asarray(mesh.tri_verts)]

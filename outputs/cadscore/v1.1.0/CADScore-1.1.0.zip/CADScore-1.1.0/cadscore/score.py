"""Local scorer for aligned watertight STL triangle meshes, in millimetres."""
import argparse
import json
import struct
import sys
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree


def read_stl(path):
    raw = Path(path).read_bytes()
    if len(raw) >= 84:
        count = struct.unpack_from('<I', raw, 80)[0]
        if len(raw) == 84 + 50 * count:
            records = struct.iter_unpack('<12fH', raw[84:])
            return np.array([r[3:12] for r in records], dtype=float).reshape(-1, 3, 3)
    vertices = []
    for line in raw.decode('ascii').splitlines():
        fields = line.lower().split()
        if fields and fields[0] == 'vertex':
            if len(fields) != 4:
                raise ValueError('Malformed ASCII STL vertex')
            vertices.append([float(value) for value in fields[1:]])
    return np.array(vertices, dtype=float).reshape(-1, 3, 3)


def cross2(a, b):
    return a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]


class Mesh:
    def __init__(self, triangles):
        self.t = np.asarray(triangles, dtype=float)
        if self.t.ndim != 3 or self.t.shape[1:] != (3, 3) or not len(self.t):
            raise ValueError('Empty or malformed mesh')
        if not np.isfinite(self.t).all():
            raise ValueError('Nonfinite mesh vertex')
        flat = self.t.reshape(-1, 3)
        self.lo = flat.min(axis=0)
        self.hi = flat.max(axis=0)
        a, b, c = self.t.transpose(1, 0, 2)
        normals = np.cross(b - a, c - a)
        self.areas = np.linalg.norm(normals, axis=1) / 2
        if np.any(self.areas <= 0):
            raise ValueError('Degenerate triangle')
        _, indices = np.unique(flat, axis=0, return_inverse=True)
        faces = indices.reshape(-1, 3)
        edges = np.column_stack((faces.ravel(), np.roll(faces, -1, axis=1).ravel()))
        pairs, group, counts = np.unique(np.sort(edges, axis=1), axis=0, return_inverse=True, return_counts=True)
        winding = np.bincount(group.ravel(), weights=np.sign(edges[:, 1] - edges[:, 0]))
        if len(pairs) == 0 or np.any(counts != 2) or np.any(winding != 0):
            raise ValueError('Mesh is open, nonmanifold at an edge, or inconsistently wound')
        self.volume = float(np.einsum('ij,ij->', a - self.lo, normals) / 6)
        if self.volume <= 0:
            raise ValueError('Nonpositive signed volume: inspect shell orientation')
        # Orient projected faces CCW. The half-open edge rule counts a shared diagonal only once.
        keep = normals[:, 0] != 0
        self.projected = self.t[keep].copy()
        flip = normals[keep, 0] < 0
        self.projected[flip] = self.projected[flip][:, [0, 2, 1]]
        self.yz = self.projected[:, :, 1:]
        self.delta = np.roll(self.yz, -1, axis=1) - self.yz
        dy, dz = self.delta.transpose(2, 0, 1)
        self.inclusive = (dz > 0) | ((dz == 0) & (dy < 0))
        self.den = cross2(self.yz[:, 1] - self.yz[:, 0], self.yz[:, 2] - self.yz[:, 0])
        self._rotated = {}

    def crossings(self, y, z):
        side = cross2(self.delta, np.array([y, z]) - self.yz)
        keep = np.all((side > 0) | ((side == 0) & self.inclusive), axis=1)
        bary = side[keep][:, [1, 2, 0]] / self.den[keep, None]
        hits = np.sort(np.sum(bary * self.projected[keep, :, 0], axis=1))
        if len(hits) % 2:
            raise ValueError('Odd ray-crossing count; inspect mesh or sampling position')
        return hits

    def material(self, xs, y, z):
        return np.searchsorted(self.crossings(y, z), xs, side='right') % 2 == 1

    def spans(self, axis, through):
        """Sorted material intervals on an axial line in world coordinates (mm)."""
        index = {'x': 0, 'y': 1, 'z': 2}[axis]
        order = [(index + k) % 3 for k in range(3)]
        if index and index not in self._rotated:
            self._rotated[index] = Mesh(self.t[:, :, order])
        view = self._rotated[index] if index else self
        return view.crossings(through[order[1]], through[order[2]]).reshape(-1, 2)

    def radial_profile(self, centre, z, directions):
        """Distance to the first wall from the nominal bore centre at one Z section."""
        if self.material(*centre, z):
            return {'centre_in_material': True, 'rays_hit': 0, 'min_mm': None, 'max_mm': None}
        ends = np.roll(self.t, -1, axis=1)
        za = self.t[:, :, 2]
        zb = ends[:, :, 2]
        cut = ((za <= z) & (z < zb)) | ((zb <= z) & (z < za))
        p = self.t[cut]
        q = ends[cut]
        xy = p[:, :2] + (q[:, :2] - p[:, :2]) * ((z - p[:, 2]) / (q[:, 2] - p[:, 2]))[:, None]
        segments = xy.reshape(-1, 2, 2)
        start = segments[:, 0] - centre
        side = segments[:, 1] - segments[:, 0]
        distances = []
        for angle in np.arange(directions) * (2 * np.pi / directions):
            direction = np.array([np.cos(angle), np.sin(angle)])
            den = cross2(direction, side)
            keep = np.abs(den) > 1e-12 * np.linalg.norm(side, axis=1)
            along = cross2(start[keep], side[keep]) / den[keep]
            segment_fraction = cross2(start[keep], direction) / den[keep]
            valid = (along > 0) & (segment_fraction >= -1e-12) & (segment_fraction <= 1 + 1e-12)
            if np.any(valid):
                distances.append(float(along[valid].min()))
        return {'centre_in_material': False, 'rays_hit': len(distances),
                'min_mm': min(distances, default=None), 'max_mm': max(distances, default=None)}

    def surface_samples(self, n, seed):
        rng = np.random.default_rng(seed)
        faces = self.t[rng.choice(len(self.t), n, p=self.areas / self.areas.sum())]
        u = np.sqrt(rng.random((n, 1)))
        v = rng.random((n, 1))
        return (1 - u) * faces[:, 0] + u * (1 - v) * faces[:, 1] + u * v * faces[:, 2]


def similarity(ref, cand, grid, samples, seed):
    if not 4 <= grid <= 128 or not 32 <= samples <= 1000000:
        raise ValueError('Use grid 4..128 and surface samples 32..1000000')
    lo = np.minimum(ref.lo, cand.lo)
    hi = np.maximum(ref.hi, cand.hi)
    step = (hi - lo) / grid
    # One lattice, same world coordinates in both meshes. Fixed phase avoids common face boundaries.
    axes = [lo[k] + (np.arange(grid) + offset) * step[k] for k, offset in enumerate((0.4913, 0.5127, 0.4781))]
    overlap = 0
    union = 0
    for y in axes[1]:
        for z in axes[2]:
            a = ref.material(axes[0], y, z)
            b = cand.material(axes[0], y, z)
            overlap += int(np.count_nonzero(a & b))
            union += int(np.count_nonzero(a | b))
    if union == 0:
        raise ValueError('Grid missed both meshes; use a finer grid or a different evaluation window')
    a = ref.surface_samples(samples, seed)
    b = cand.surface_samples(samples, seed + 1)
    cd = (cKDTree(a).query(b)[0].mean() + cKDTree(b).query(a)[0].mean()) / 2
    return {'voxel_iou': overlap / union, 'grid_step_mm': step.tolist(), 'surface_chamfer_mm': float(cd),
            'grid_per_axis': grid, 'surface_points_per_mesh': samples, 'seed': seed}


def check(mesh, rules):
    if not isinstance(rules, list) or not rules:
        raise ValueError('Supply at least one explicit requirement')
    result = []
    for rule in rules:
        kind = rule['kind']
        if kind in ('extent_mm', 'volume_mm3'):
            if kind == 'extent_mm':
                axis = {'x': 0, 'y': 1, 'z': 2}[rule['axis']]
                actual = float(mesh.hi[axis] - mesh.lo[axis])
            else:
                actual = mesh.volume
            target = float(rule['target'])
            tolerance = float(rule['tolerance'])
            if not np.isfinite([target, tolerance]).all() or tolerance < 0:
                raise ValueError('Invalid target or tolerance')
            passed = abs(actual - target) <= tolerance
        elif kind == 'ray_intervals_mm':
            through = np.asarray(rule['through_mm'], dtype=float)
            target = np.asarray(rule['target'], dtype=float)
            if target.shape == (0,):
                target = target.reshape(0, 2)
            tolerance = float(rule['tolerance'])
            if through.shape != (3,) or not np.isfinite(through).all():
                raise ValueError('Ray needs a finite XYZ location')
            if target.ndim != 2 or target.shape[1] != 2 or not np.isfinite(target).all():
                raise ValueError('Ray target must be a list of finite [entry, exit] pairs')
            if np.any(np.diff(target.ravel()) <= 0) or not np.isfinite(tolerance) or tolerance < 0:
                raise ValueError('Ray intervals must be increasing and tolerance nonnegative')
            measured = mesh.spans(rule['axis'], through)
            passed = measured.shape == target.shape and np.all(np.abs(measured - target) <= tolerance)
            actual = measured.tolist()
        elif kind == 'bore_profile_mm':
            centre = np.asarray(rule['centre_xy_mm'], dtype=float)
            levels = np.asarray(rule['z_mm'], dtype=float)
            target = float(rule['target'])
            tolerance = float(rule['tolerance'])
            directions = rule['directions']
            if centre.shape != (2,) or levels.ndim != 1 or not 1 <= len(levels) <= 128:
                raise ValueError('Bore profile needs an XY centre and 1..128 Z levels')
            if not np.isfinite(centre).all() or not np.isfinite(levels).all():
                raise ValueError('Nonfinite bore section location')
            if not np.isfinite([target, tolerance]).all() or not 0 <= tolerance < target:
                raise ValueError('Expected positive radius and smaller nonnegative tolerance')
            if type(directions) is not int or not 8 <= directions <= 720:
                raise ValueError('Expected 8..720 angular directions')
            actual = [mesh.radial_profile(centre, z, directions) for z in levels]
            passed = all(section['rays_hit'] == directions and
                         section['min_mm'] >= target - tolerance and section['max_mm'] <= target + tolerance
                         for section in actual)
        elif kind == 'point_material':
            xyz = np.array(rule['xyz_mm'], dtype=float)
            if xyz.shape != (3,) or not np.isfinite(xyz).all() or not isinstance(rule['target'], bool):
                raise ValueError('Probe needs a finite interior/exterior point and boolean target')
            actual = bool(mesh.material(*xyz))
            passed = actual == rule['target']
        else:
            raise ValueError(f'Unsupported requirement: {kind}')
        result.append({**rule, 'actual': actual, 'pass': bool(passed)})
    return result


def score(ref, cand, spec, grid=32, samples=4096, seed=42):
    if spec.get('units') != 'mm':
        raise ValueError('Expected explicit units: mm')
    rules = spec['requirements']
    if not all(row['pass'] for row in check(ref, rules)):
        raise ValueError('Reference violates its own requirements')
    rows = check(cand, rules)
    return {'case': spec.get('id'), 'passes_spec': all(row['pass'] for row in rows),
            'checks_passed': sum(row['pass'] for row in rows), 'checks_total': len(rows), 'requirements': rows,
            'similarity': similarity(ref, cand, grid, samples, seed)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('spec', type=Path)
    parser.add_argument('--grid', type=int, default=32)
    parser.add_argument('--samples', type=int, default=4096)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    try:
        report = score(Mesh(read_stl(args.reference)), Mesh(read_stl(args.candidate)),
                       json.loads(args.spec.read_text()), args.grid, args.samples, args.seed)
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(f'Input error: {exc}', file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2, allow_nan=False))
    return 0 if report['passes_spec'] else 1


if __name__ == '__main__':
    sys.exit(main())

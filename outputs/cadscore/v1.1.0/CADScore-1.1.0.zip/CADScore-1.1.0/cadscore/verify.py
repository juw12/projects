"""Original fixtures, regression checks and a reproducible local demo; no network I/O."""
import argparse
import contextlib
import io
import json
import struct
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from .score import Mesh, check, main as score_cli, read_stl, score, similarity


def plate(w, d, h, slot=None):
    xs = sorted({0, w, *(slot[:2] if slot else [])})
    ys = sorted({0, d, *(slot[2:] if slot else [])})
    cells = {(i, j) for i in range(len(xs) - 1) for j in range(len(ys) - 1)}
    if slot:
        cells.remove((xs.index(slot[0]), ys.index(slot[2])))
    triangles = []

    def quad(p0, p1, p2, p3):
        triangles.extend([[p0, p1, p2], [p0, p2, p3]])

    for i, j in sorted(cells):
        x, xx = xs[i:i+2]
        y, yy = ys[j:j+2]
        corners = [(x, y), (xx, y), (xx, yy), (x, yy)]
        bottom = [(*p, 0) for p in corners]
        top = [(*p, h) for p in corners]
        quad(*bottom[::-1])
        quad(*top)
        for k, neighbor in enumerate(((i, j-1), (i+1, j), (i, j+1), (i-1, j))):
            if neighbor not in cells:
                m = (k + 1) % 4
                quad(bottom[k], bottom[m], top[m], top[k])
    return np.array(triangles, dtype=float)


def write_stl(path, triangles):
    with path.open('wb') as f:
        f.write(struct.pack('<80sI', b'Synthetic CAD scoring fixture; units mm', len(triangles)))
        for triangle in triangles:
            f.write(struct.pack('<12fH', 0, 0, 0, *triangle.ravel(), 0))


def fixtures():
    w, d, h = 30, 18, 4
    slot = (13, 17, 6, 12)
    spec = {'id': 'slotted-plate', 'units': 'mm',
            'prompt': '30 by 18 by 4 mm plate, lower corner at the origin. Centre a 4 by 6 mm rectangular through-opening on its top face.',
            'requirements': [{'kind': 'extent_mm', 'axis': axis, 'target': dim, 'tolerance': 0.05}
                             for axis, dim in zip('xyz', (w, d, h))]}
    spec['requirements'].append({'kind': 'volume_mm3', 'target': (w*d-4*6)*h, 'tolerance': 1})
    # Strictly away from every face; sampled occupancy, not metrology of the entire opening.
    for point, material in [([15, 9, 0.25], False), ([15, 9, 2], False), ([15, 9, 3.75], False),
                            ([12.75, 9, 2], True), ([17.25, 9, 2], True), ([15, 5.75, 2], True), ([15, 12.25, 2], True)]:
        spec['requirements'].append({'kind': 'point_material', 'xyz_mm': point, 'target': material})
    cases = {'nominal': plate(w, d, h, slot), 'shifted-opening': plate(w, d, h, (16, 20, 6, 12)),
             'filled-opening': plate(w, d, h), 'too-thick': plate(w, d, 5, slot)}
    return spec, cases


def demo(directory, grid=32, samples=4096):
    directory.mkdir(parents=True, exist_ok=True)
    spec, cases = fixtures()
    names = [directory / 'spec.json', directory / 'results.json', *(directory / f'{name}.stl' for name in cases)]
    if any(p.exists() for p in names):
        raise ValueError('Refusing to overwrite demo outputs; choose an empty directory')
    (directory / 'spec.json').write_text(json.dumps(spec, indent=2) + '\n')
    for name, mesh in cases.items():
        write_stl(directory / f'{name}.stl', mesh)
    ref = Mesh(read_stl(directory / 'nominal.stl'))
    results = {name: score(ref, Mesh(read_stl(directory / f'{name}.stl')), spec, grid, samples) for name in cases}
    (directory / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    for name, row in results.items():
        print(f"{name:18s} {row['checks_passed']:2}/{row['checks_total']}  IoU={row['similarity']['voxel_iou']:.4f}  pass={row['passes_spec']}")
    return results


class Tests(unittest.TestCase):
    def setUp(self):
        self.spec, self.cases = fixtures()
        self.ref = Mesh(self.cases['nominal'])

    def test_nominal(self):
        result = score(self.ref, self.ref, self.spec, grid=12, samples=128)
        self.assertTrue(result['passes_spec'])
        self.assertEqual(result['similarity']['voxel_iou'], 1.0)
        self.assertAlmostEqual(self.ref.volume, 2064)

    def test_shift_location_not_volume(self):
        shifted = Mesh(self.cases['shifted-opening'])
        self.assertAlmostEqual(shifted.volume, self.ref.volume)
        rows = check(shifted, self.spec['requirements'])
        self.assertTrue(all(r['pass'] for r in rows[:4]))
        self.assertFalse(all(r['pass'] for r in rows))
        iou = similarity(self.ref, shifted, 32, 128, 1)['voxel_iou']
        self.assertAlmostEqual(iou, 498 / 534, delta=0.02)

    def test_filled_and_thick(self):
        for name in ('filled-opening', 'too-thick'):
            rows = check(Mesh(self.cases[name]), self.spec['requirements'])
            self.assertFalse(next(row for row in rows if row['kind'] == 'volume_mm3')['pass'])

    def test_open_and_winding(self):
        for t in (self.ref.t[:-1], self.ref.t[:, ::-1], np.concatenate([self.ref.t, self.ref.t[:1]])):
            with self.assertRaises(ValueError):
                Mesh(t)

    def test_disjoint_and_reproducible(self):
        translated = Mesh(self.ref.t + [31, 0, 0])
        first = similarity(self.ref, translated, 12, 128, 7)
        self.assertEqual(first['voxel_iou'], 0)
        self.assertGreater(first['surface_chamfer_mm'], 1)
        self.assertEqual(first, similarity(self.ref, translated, 12, 128, 7))

    def test_sampling_on_shared_diagonal(self):
        cube = Mesh(plate(2, 2, 2))
        self.assertEqual(cube.material(np.array([-1, 1, 3]), 1., 1.).tolist(), [False, True, False])

    def test_invalid_reference(self):
        with self.assertRaises(ValueError):
            score(Mesh(self.cases['filled-opening']), self.ref, self.spec, 8, 32)

    def test_ascii_and_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'input.stl'
            write_stl(path, self.ref.t)
            self.assertTrue(np.array_equal(read_stl(path), self.ref.t))
            lines = ['solid fixture']
            for face in self.ref.t:
                lines.extend(['facet normal 0 0 0', 'outer loop'])
                lines.extend('vertex ' + ' '.join(str(v) for v in p) for p in face)
                lines.extend(['endloop', 'endfacet'])
            lines.append('endsolid fixture')
            path.write_text('\n'.join(lines))
            self.assertTrue(np.array_equal(read_stl(path), self.ref.t))

    def test_cli_exit_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            ref = folder / 'ref.stl'
            cand = folder / 'cand.stl'
            spec = folder / 'spec.json'
            write_stl(ref, self.ref.t)
            spec.write_text(json.dumps(self.spec))
            for mesh, status in [(self.ref.t, 0), (self.cases['filled-opening'], 1), (self.ref.t[:-1], 2)]:
                write_stl(cand, mesh)
                argv = ['score.py', str(ref), str(cand), str(spec), '--grid', '8', '--samples', '32']
                with patch('sys.argv', argv), contextlib.redirect_stdout(io.StringIO()) as out, contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(score_cli(), status)
                    if status < 2:
                        self.assertIs(json.loads(out.getvalue())['passes_spec'], status == 0)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo', type=Path, help='Generate specs, STL fixtures and scored JSON in an empty directory')
    args = parser.parse_args()
    if args.demo is None:
        unittest.main(argv=['verify.py'], verbosity=2)
    else:
        demo(args.demo)

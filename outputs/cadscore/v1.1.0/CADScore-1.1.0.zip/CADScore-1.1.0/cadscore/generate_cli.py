"""Generate one constrained English plate specification as a millimetre STL."""
import argparse
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile
import os


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prompt', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(argv)
    temporary = None
    try:
        from .generator import generate, rule_router
        from .score import Mesh
        from .verify import write_stl
        if args.out.exists():
            raise ValueError('Refusing to overwrite an existing output')
        family, triangles = generate(args.prompt, rule_router)
        Mesh(triangles)
        with NamedTemporaryFile(dir=args.out.parent, delete=False) as stream:
            temporary = Path(stream.name)
        write_stl(temporary, triangles)
        os.link(temporary, args.out)
        print(f'Generated {family}: {args.out.resolve()}')
        return 0
    except (OSError, ValueError, RuntimeError, ImportError) as error:
        print(f'Cannot generate: {error}', file=sys.stderr)
        return 2
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    sys.exit(main())

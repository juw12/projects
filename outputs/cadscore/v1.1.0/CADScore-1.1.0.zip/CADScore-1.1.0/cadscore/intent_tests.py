import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from .generate_cli import main
from .generator import generate, rule_router
from .score import Mesh, read_stl


class IntentTests(unittest.TestCase):
    def test_rejects_contradictions_and_unsupported_geometry(self):
        stock = 'A 30 by 20 by 5 mm plate. '
        pocket = 'Cut a centred 6 by 4 mm pocket, 2 mm deep, '
        pattern = 'Cut a centred row of three through holes, diameter 2 mm, pitch 5 mm '
        prompts = [
            pocket + 'from the top and the underside.',
            pocket + 'from the top, not from the top.',
            pocket + 'from the left face.',
            pattern + 'along X and along Y.',
            pattern + 'along Z.',
            pattern + 'in a diagonal line.',
            pattern.replace('pitch 5 mm', 'pitch 1 mm') + 'along Y.',
            pocket + 'from above and add a circular bore.',
        ]
        for prompt in prompts:
            with self.subTest(prompt=prompt):
                with self.assertRaises(ValueError):
                    generate(stock + prompt, rule_router)

    def test_cli_no_clobber(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stderr(io.StringIO()):
            path = Path(tmp) / 'keep.stl'
            path.write_bytes(b'keep')
            self.assertEqual(main(['--out', str(path), '--prompt', 'plate']), 2)
            self.assertEqual(path.read_bytes(), b'keep')

    def test_refusal_leaves_no_output(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stderr(io.StringIO()):
            path = Path(tmp) / 'bad.stl'
            self.assertEqual(main(['--out', str(path), '--prompt', 'unknown']), 2)
            self.assertFalse(path.exists())

    def test_cli_generates_specified_face(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            path = Path(tmp) / 'candidate.stl'
            prompt = '25 by 18 by 5 mm plate, centred 6 by 4 mm pocket, 2 mm deep, from the underside.'
            self.assertEqual(main(['--out', str(path), '--prompt', prompt]), 0)
            mesh = Mesh(read_stl(path))
            self.assertFalse(mesh.material(12.57, 9.13, 1))
            self.assertTrue(mesh.material(12.57, 9.13, 4))

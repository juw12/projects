"""Evaluate immutable prompts with two prompt-only generator modes. No calls to hosted APIs."""
import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np

from .benchmark import bore_profile, ray, requirements, triangulate_plate
from .generator import SemanticRouter, generate, rule_router
from .score import Mesh, check, read_stl, score
from .verify import write_stl


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(case):
    w, d, h = case['stock_mm']
    family = case['family']
    p = case['parameters_mm']
    x, y = p[:2]
    if family.startswith('pocket'):
        u, v, depth = p[2:]
        surf_z = h - depth / 2 if family == 'pocket' else depth / 2
        vertical = [[0, h - depth]] if family == 'pocket' else [[depth, h]]
        spec = requirements(case['id'], case['prompt'], w, d, h, w*d*h-u*v*depth, 0.6)
        spec['requirements'].extend([
            ray('z', [x + 0.07, y + 0.09, 0], vertical),
            ray('x', [0, y + 0.11, surf_z], [[0, x-u/2], [x+u/2, w]]),
            ray('y', [x + 0.09, 0, surf_z], [[0, y-v/2], [y+v/2, d]]),
        ])
        triangles = triangulate_plate(w, d, h, [{'center': (x,y), 'size': (u,v), 'floor': h-depth}])
        if family == 'pocket-bottom':
            triangles[:, :, 2] = h - triangles[:, :, 2]
            triangles = triangles[:, ::-1]
    else:
        r = p[2]
        n, pitch = p[3:] if family != 'bore' else (1, 0)
        along_y = family == 'pattern-y'
        offset = [(i-(n-1)/2) * pitch for i in range(n)]
        centres = [(x, y+q) if along_y else (x+q, y) for q in offset]
        spec = requirements(case['id'], case['prompt'], w, d, h, w*d*h - math.pi*r*r*n*h, max(1.5, math.pi*r*r*n*h*0.009))
        for xx, yy in centres:
            feature = bore_profile(xx, yy, r)
            feature['z_mm'] = [0.27*h, 0.61*h]
            spec['requirements'].extend([feature, ray('z', [xx + 0.07, yy + 0.11, 0], [])])
        if along_y:
            triangles = triangulate_plate(d/n, w, h, [{'center': (yy, xx), 'radius': r} for xx, yy in centres])
            triangles = triangles[:, ::-1, :][:, :, [1, 0, 2]]
        else:
            triangles = triangulate_plate(w/n, d, h, [{'center': (xx, yy), 'radius': r} for xx, yy in centres])
    return triangles, spec


def run(dataset, encoder, out):
    cases = json.loads((dataset / 'heldout.json').read_text())
    hashes = json.loads((dataset / 'freeze.json').read_text())
    for path, key in [(dataset/'heldout.json','cases'), (Path(__file__).with_name('generator.py'),'generator'),
                      (encoder/'model.onnx','model_sha256'), (encoder/'tokenizer.json','tokenizer_sha256')]:
        if digest(path) != hashes[key]:
            raise ValueError(f'Frozen artifact changed: {path}')
    out.mkdir(exist_ok=False, parents=True)
    refs = {}
    for case in cases:
        case_dir = out / case['id']
        case_dir.mkdir()
        triangles, spec = reference(case)
        path = case_dir / 'reference.stl'
        write_stl(path, triangles)
        mesh = Mesh(read_stl(path))
        checks = check(mesh, spec['requirements'])
        if not all(row['pass'] for row in checks):
            raise ValueError(f"Reference fails declared requirements: {case['id']}, {checks}")
        (case_dir/'spec.json').write_text(json.dumps(spec, indent=2) + '\n')
        refs[case['id']] = (mesh, spec)
    start = time.perf_counter()
    semantic = SemanticRouter(encoder)
    model_init = time.perf_counter() - start
    rows = []
    for mode, route in [('rules', rule_router), ('encoder', semantic)]:
        for case in cases:
            start = time.perf_counter()
            ref, spec = refs[case['id']]
            result = {'mode': mode, 'id': case['id'], 'family': case['family'], 'routed_to': '', 'status': '', 'error': '', 'iou': '', 'chamfer_mm': '', 'generation_s': '', 'scoring_s': '', 'failed_rules': ''}
            path = out / case['id'] / f'{mode}.stl'
            try:
                label, triangles = generate(case['prompt'], route)
                result['routed_to'] = label
                write_stl(path, triangles)
            except (ValueError, RuntimeError) as exc:
                result.update(status='no_output', error=str(exc))
            result['generation_s'] = time.perf_counter() - start
            if path.is_file():
                start = time.perf_counter()
                try:
                    candidate = Mesh(read_stl(path))
                except ValueError as exc:
                    result.update(status='invalid_mesh', error=str(exc))
                else:
                    report = score(ref, candidate, spec, grid=24, samples=4096, seed=42)
                    result['status'] = 'pass' if report['passes_spec'] else 'wrong_geometry'
                    result['failed_rules'] = '|'.join(row['kind'] for row in report['requirements'] if not row['pass'])
                    result['iou'] = report['similarity']['voxel_iou']
                    result['chamfer_mm'] = report['similarity']['surface_chamfer_mm']
                    path.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
                result['scoring_s'] = time.perf_counter() - start
            rows.append(result)
    with (out / 'results.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (out / 'runtime.json').write_text(json.dumps({'encoder_init_s': model_init, 'grid': 24, 'samples': 4096, 'seed': 42}, indent=2) + '\n')
    for mode in ('rules', 'encoder'):
        group = [r for r in rows if r['mode'] == mode]
        print(mode, {key: sum(r['status'] == key for r in group) for key in ('pass', 'wrong_geometry', 'invalid_mesh', 'no_output')})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', type=Path)
    parser.add_argument('encoder', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.dataset, args.encoder, args.output)

# CADScore: a local STL requirement scorer

Input: two pre-aligned watertight STL triangle meshes, plus a JSON spec. Output: per-requirement pass/fail (including axial lengths and sampled bore profiles), approximate volumetric IoU and sampled symmetric surface Chamfer distance. This scores geometry produced by a designer or generator; it is not itself a CAD generator. No network, API key or workplace material is used. The code and demo fixtures were AI-generated.

## Reproduce locally

Use a Python 3 environment with NumPy and SciPy. From this directory:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install numpy scipy
python -m cadscore.verify                       # nine regression tests
python -m cadscore.verify --demo demo            # use an empty or nonexistent output directory
cadscore demo/nominal.stl demo/shifted-opening.stl demo/spec.json
```

The last command is supposed to return exit 1 and a JSON report: the opening in the candidate is misplaced. Exit 0 means all listed requirements passed; exit 2 means input or evaluation error. Demo generation writes the reference, three candidate mutations, the human-readable prompt and the results JSON into the requested directory. It refuses to overwrite prior demo files.

## What was tested

A synthetic 30 by 18 by 4 mm plate with a centred 4 by 6 mm rectangular through-opening. All meshes use the same coordinate frame. The 11 requirements are three external dimensions, net material volume, and seven material/void witness points. At 32 grid samples per axis and 4,096 surface points per mesh, seed 42:

| Candidate | Passed checks | Volume overlap (IoU) | Whole spec |
|---|---:|---:|---|
| Reference against itself | 11/11 | 1.0000 | Pass |
| Opening displaced 3 mm | 7/11 | 0.9408 | Fail |
| Opening filled in | 7/11 | 0.9609 | Fail |
| Plate 1 mm too thick | 9/11 | 0.8125 | Fail |

The misplaced opening passes *all external dimensions and the net volume check*. The material/void probes catch the defect. These are deliberately constructed tests of the scorer, not measurements of any AI model's accuracy.

## Spec and metrics

- `units` must be `mm`. An STL contains no reliable unit or coordinate-frame declaration; export both models in the same specified frame. No automatic rescaling or alignment.
- `extent_mm`: world-axis bounding-box extent (`axis`: `x`, `y` or `z`; numeric `target` and absolute `tolerance`). This is a dimension, not a position check.
- `volume_mm3`: signed enclosed mesh volume with absolute tolerance. Requires correct shell orientations.
- `point_material`: strictly interior or exterior `xyz_mm` witness point with boolean `target` (`true` = material, `false` = empty). Do not place probes on boundaries. Probes are spot checks, not a proof of exact bore diameter, wall thickness, or uninterrupted clearance.
- Whole-spec pass requires every listed check to pass. If the reference violates the spec, the scorer reports input error, not a candidate failure.
- IoU: common lattice in the combined bounding box; intersection occupied count divided by union occupied count. Thin features can be missed. The report includes the physical grid spacing. Repeat at higher `--grid` before interpreting small differences.
- Chamfer: area-weighted independent surface samples, Euclidean nearest-neighbour distance each way, averaged and **not squared**, in mm. Identical shapes need not score zero due to independent sampling. Increase `--samples` and repeat with different `--seed` values when comparing close scores.
- Import checks finite vertices, nondegenerate triangles, twice-used edges with opposite winding, and positive total volume. It does **not** detect all self-intersections, coincident shells, flipped internal shells or vertex-only nonmanifold cases. Use clean exported meshes. Not a STEP/B-rep inspector or a manufacturing acceptance test.

## Extended benchmark: blind pockets, bores and hole patterns

```sh
python -m cadscore.benchmark --test
python -m cadscore.benchmark --report benchmark-results.csv
```

The original suite has nine tests, the extended suite four test methods with multiple cases. The CSV contains all 13 labelled variants under five sampling configurations. Ground truth comes from the fixture's construction parameters, not the scorer. All fixtures are synthetic and the checks were refined on this set; it is **not** a held-out evaluation or a measure of model accuracy.

- `ray_intervals_mm` measures the sorted [entry, exit] coordinates of material along an `axis` through a supplied XYZ location (`through_mm`). Include all expected material intervals in `target` (including an empty list for an unobstructed path). The tolerance applies per endpoint in mm. Choose a line away from tangent edges and surfaces coinciding with the line.
- `bore_profile_mm` casts radial rays in a horizontal section from `centre_xy_mm`. Supply `z_mm` levels strictly within the feature, `directions` per level, radius `target` and absolute `tolerance`. Each direction must reach a wall within tolerance. Use sufficiently fine tessellation and avoid floors or shoulders at the selected levels. A defect between angles or between the sampled heights can still escape detection.

| Family | Conforming accepted | Defects rejected before radial checks | Defects rejected after |
|---|---:|---:|---:|
| Blind pocket | 1/1 | 3/3 | 3/3 |
| Circular bore | 2/2 | 3/3 | 3/3 |
| Three-hole pattern | 1/1 | 2/3 | 3/3 |

The lobed middle bore had the correct cardinal diameters. At a 24-per-axis grid it had IoU 0.9963; the axial checks alone accepted it. The new profile rule sampled 32 directions at each of two heights and measured extrema 1.32 and 1.68 mm against an allowed 1.45–1.55 mm. The within-tolerance bore, shifted by 0.03 mm against a 0.05 mm allowance, still passed.

Sampling sensitivity: for the lobed bore the IoU was 0.9861, 0.9963 and 0.9961 on grids of 12, 24 and 40 samples per axis. At seed 42, increasing surface points per mesh from 512 to 4,096 lowered measured Chamfer from 0.7783 to 0.2791 mm; at 4,096 points, changing seed to 71 gave 0.2815 mm. These shape metrics should not be compared across different sampling settings as if they were measurements of dimensional error. Nothing here certifies the geometry for manufacturing.

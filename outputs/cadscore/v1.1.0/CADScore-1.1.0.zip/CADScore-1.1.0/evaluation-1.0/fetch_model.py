"""Fetch only the pinned public MiniLM files, verifying them before use. Requires curl."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    destination = parser.parse_args().destination
    destination.mkdir(parents=True, exist_ok=True)
    freeze = json.loads(Path(__file__).with_name('freeze.json').read_text())
    base = 'https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/'
    for remote, local, checksum in [
        ('onnx/model_quint8_avx2.onnx', 'model.onnx', freeze['model_sha256']),
        ('tokenizer.json', 'tokenizer.json', freeze['tokenizer_sha256']),
    ]:
        path = destination / local
        if path.exists():
            if hashlib.sha256(path.read_bytes()).hexdigest() == checksum:
                print('Verified:', path)
                continue
            raise ValueError('Refusing to overwrite a file with a different checksum: ' + str(path))
        tmp = path.with_suffix('.partial')
        url = base + freeze['encoder_revision'] + '/' + remote
        subprocess.run(['curl', '--fail', '--location', '--retry', '2', '--max-time', '180', url, '-o', str(tmp)], check=True)
        if hashlib.sha256(tmp.read_bytes()).hexdigest() != checksum:
            tmp.unlink()
            raise ValueError('Downloaded file failed SHA-256 validation')
        tmp.replace(path)
        print('Verified:', path)


if __name__ == '__main__':
    main()

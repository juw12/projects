# CADScore 1.1.0

Local English-to-STL generator and dimensional requirement scorer for simple millimetre plates. The generator is procedural. An optional sentence encoder can help classify feature wording, but explicit operation nouns and hole-pattern instructions take precedence. The scorer and model weights have not changed since 1.0. No API calls or employer data are used for generation or scoring.

## Install and try it

From this extracted release, in a Python 3.9+ virtual environment:

```sh
python -m pip install './cadscore_local-1.1.0-py3-none-any.whl[generator]'
cadscore-generate --prompt '25 by 18 by 5 mm plate, centred 6 by 4 mm pocket, 2 mm deep, from the underside.' --out underside.stl
cadscore evaluation/run/N01/reference.stl evaluation/run/N01/rules.stl evaluation/run/N01/spec.json
python -m unittest -v cadscore.verify cadscore.benchmark cadscore.intent_tests
```

The generation command uses deterministic routing and refuses to overwrite an existing file. It validates mesh topology, not the completeness or manufacturability of the design. Use the independent scorer to check requirements. Understood geometry is one rectangular blind pocket, one vertical circular through bore, or an evenly spaced X/Y row of bores in an axis-aligned rectangular plate. If no pocket face is stated the generator assumes the top; if no pattern axis is stated it assumes X. This is a constrained parser, not a safety checker: explicit conflict and unsupported-geometry guards do not catch every possible paraphrase.

## Reproduce the evaluations

```sh
python -m pip install './cadscore_local-1.1.0-py3-none-any.whl[evaluation]'
python evaluation/fetch_model.py local-encoder
python -m cadscore.experiment replay local-encoder new-regression-run
python -m cadscore.experiment evaluation local-encoder new-challenge-run
```

`evaluation-1.0` contains historical 1.0.0 evidence, not a dataset that can be replayed against the changed generator. The generator hashes for `replay` and `evaluation` pin 1.1.0. `replay` uses exactly the original 16 prompts; `evaluation` has eight new targeted prompts. Results include missing output, wrong geometry and individual checks, with no external publishing or claims of manufacturing validation. Model and direct dependency versions are recorded with the evaluation. Original source and benchmark data are under the bundled MIT licence. The separately downloaded MiniLM encoder is Apache-2.0, pinned to revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41; third-party software retains its own licences.
